<?php require('session.php'); ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Medicine</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/rabon.css">
    <link rel="stylesheet" href="css/stylephp.css">
    <script src="js/clock.js" charset="utf-8"></script>
    <script src="js/calander.js" charset="utf-8"></script>
</head>
  <body onload="displayCalendar(),startTime()" >
    <!--Hospital Name start-->
    <div class="name">
      <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
<div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
      <div><h2>Hospital Management System</h2></div>
    </div>
    <!--Hospital Name End-->
    <!--1st header-->
      <div class="header">
          <div class="admin">
            <marquee behavior="alternate" scrollamount="2s"><h4><?php
            include('dbconnect.php');
              if (!mysqli_connect_errno()) {
                $query = "SELECT * FROM user WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);

                if($result){
                  echo "Current User:-".$row['username'];
                }
              }?></h4></marquee>
          </div>
          <div class="logout">
            <a  href="home.php">Home</a>
            <a href="doctor.php">Doctor's</a>
            <a href="nurse.php">Nurse</a>
            <a href="patient.php">Patient's</a>
            <a href="pharmacist.php">Pharamacist</a>
            <a href="labrotorist.php">Laboratist</a>
            <a href="accounts.php">Account's</a>
            <a href="profile.php">Profile</a>
            <a href="logout.php">Logout</a>
          </div>
      </div>
      <!--1st header end-->

      <!--Home page menue start-->
      <div class="menue">
        <a href="appoitmentlist.php">Appoinment</a>
        <a href="blood.php">Bloodbank</a>
        <a class= "active" href="medicine.php">Medicine</a>
        <a href="operationlist.php">Operation's</a>
        <a href="birthreport.php">Birth Report</a>
        <a href="deathreport.php">Death Report</a>
        <a href="beddetails.php">Bed Status </a>
      </div>

      <!--Home page menue End-->
      <!--Analog Clock-->
      <div id="sabuj">
      <h1>Courrent Time</h1>
      <div id="a1"></div>
      </div>
      <!--Calander-->
<div class="calander">

	<div id="calendar"></div>
</div>

<!--appoinment Form-->
<div id="navbar">
  <div class="submenu">
    <a href="admedicine.php">Add Medicine</a>
  </div>
      <div class="non-semantic-protector">
        <h1 class="ribbon">
          <strong class="ribbon-content">Medicine Records</strong>
        </h1>
      </div>
</div>
 <!-- Search Filter-->
 <form method="post" action="medicine.php" style="margin-top: -20px;padding: 4px;">
   <input  type="text" name="q" placeholder="Check Validity..." style="border:1px solid lightgray; border-radius: 6px;">
   <select name="column" style="border:1px solid lightgray; border-radius: 6px;height:30px;">
     <option value="">--Select--</option>
     <option value="mname">Name</option>
     <option value="catagory">Catagory</option>
     <option value="shelf">Shelf</option>
   </select>
   <input type="submit" name="submit" value="Check" style="border-radius:3px;width:80px;border:1px solid lightgray;margin-left:0px; font-weight:bold;" >
 </form>
 <?php
  if (isset($_POST['submit'])) {
    $connection = new mysqli("localhost", "root", "", "project");
    $q = $connection->real_escape_string($_POST['q']);
    $column = $connection->real_escape_string($_POST['column']);

    if ($column == "" || ($column != "mname" && $column != "catagory" && $column != "shelf"))
      $column = "mname" && "catagory" && "shlf";
    $sql = $connection->query("SELECT mname, catagory, shelf FROM medicine WHERE $column LIKE '%$q%'");
    if ($sql->num_rows > 0) {
      while ($data = $sql->fetch_array())
        echo "Name-".$data['mname'].", "."Catagory-". $data['catagory'].", "."Shelf-". $data['shelf']."<br>";

    } else
      echo "<b>"."Data Not Valid, Check Again"."</b>";
  }
 ?>
 <br>
<!--Write Data in Medicine-->
<?php
include('dbconnect.php');
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM medicine WHERE `visible` = 1";
    $result = mysqli_query($connection, $query);

    if($result){
      echo "<table id='tbl'>
    <tr>
      <th style= 'width:4%;'>Sl. No.</th>
      <th>Medicine Name</th>
      <th>Catagory </th>
      <th>Generic</th>
      <th>Shelf</th>
      <th>Quantity</th>
      <th>Unit </th>
      <th>Purchase Price</th>
      <th>Sell Price</th>
      <th>Expire Date</th>
      <th>Supplier</th>
      <th>Pharmacists</th>
      <th>Medicine ID</th>
      <th>Manage</th>

    </tr> ";
    //reference number

    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td style='text-align:left;width:15%'>".ucwords($row['mname'])."</td>";
      echo "<td>".$row['catagory']."</td>";
      echo "<td>".$row['genric']."</td>";
      echo "<td>".$row['shelf']."</td>";
      echo "<td>".$row['quantity']."</td>";
      echo "<td>".$row['unit']."</td>";
      echo "<td>".$row['pprice']." ৳"."</td>";
      echo "<td>".$row['sprice']." ৳"."</td>";
      echo "<td>".$row['edate']."</td>";
      echo "<td>".$row['supliername']."</td>";
      echo "<td>".$row['phaname']."</td>";
      echo "<td>".$row['mid']."</td>";
      echo "<td style = 'width:100px;'>"."<a href = 'printappointment.php?id=$id' id='update'>View</a>"."</td>";
      echo "</tr>";
  }
echo "</table>";
}
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
 ?>
 <div class="footer">
  <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
 </div>

  </body>

</html>
