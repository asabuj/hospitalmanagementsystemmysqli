<?php
require('session.php');
 ?>
<!DOCTYPE html>
<html>
<!--
//Programar: Sabuj Chandra roy
//Hospital Management System Project
//Database name Project;
//Uses All different table
//Create Start date: 02-01-2018
//Last Update: 07-03-2018
-->
  <head>
    <meta charset="utf-8">
    <title>Home</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/clock.js" charset="utf-8"></script>
    <script src="js/calander.js" charset="utf-8"></script>
</head>
  <body onload="displayCalendar(),startTime()" >
    <!--Hospital Name start-->
    <div class="name">
      <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
      <div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
      <div><h2>Hospital Management System</h2></div>
    </div>
    <!--Hospital Name End-->
    <!--1st header-->
      <div class="header">
          <div class="admin">
            <marquee behavior="alternate" scrollamount="2s"><h4><?php
            include('dbconnect.php');
              if (!mysqli_connect_errno()) {
                $query = "SELECT * FROM user WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);

                if($result){
                  echo "Current User:-".$row['username'];
                }
              }?></h4></marquee>
          </div>
          <div class="logout">
            <a  class= "active" href="home.php">Home</a>
            <a href="doctor.php">Doctor's</a>
            <a href="nurse.php">Nurse</a>
            <a href="patient.php">Patient's</a>
            <a href="pharmacist.php">Pharamacist</a>
            <a href="labrotorist.php">Laboratist</a>
            <a href="accounts.php">Account's</a>
            <a href="profile.php">Profile</a>
            <a href="logout.php">Logout</a>
          </div>
      </div>
      <!--1st header end-->

      <!--Home page menue start-->
      <div class="menue">
        <a href="appoitmentlist.php">Appoinment</a>
        <a href="blood.php">Bloodbank</a>
        <a href="medicine.php">Medicine</a>
        <a href="operationlist.php">Operation's</a>
        <a href="birthreport.php">Birth Report</a>
        <a href="deathreport.php">Death Report</a>
        <a href="beddetails.php">Bed Status </a>
      </div>
      <!--Home page menue End-->
      <!--Analog Clock-->
      <div id="sabuj">
      <h1>Current Time</h1>
      <div id="a1"></div>
      </div>
      <!--Calander-->
      <div class="calander">
      	<div id="calendar"></div>
      </div>
<div class="wellcome">
<figure style="float:left;"> <img src="imge/suman.jpg" style="height:175px; width:135px;"><figcaption>শ্রদ্ধেয় সুমন স্যার</figcaption>
</figure>
  <figure style="float:right;"> <img src="imge/sabuj.png" alt="" style="height:150px; width:135px;float:right;padding-left:7px;"><figcaption>আমি নিজে</figcaption>
  </figure>
  <h3 style="text-align:center;"> আমার কিছু কথা</h3>
  <p style="text-align:justify; font-family: sans-serif;margin-left:1%; margin-right:1%;">আমি সবুজ চন্দ্র রায়, দিনাজপুর সরকারী কলেজ থেকে গণিত বিভাগে অনার্স সম্পন্ন করি ২০১৪ সালে। আমি বর্তমানে আইসিটি মন্ত্রনালয়ের অধীনে LICT প্রকল্পের BDJOBS এর দিনাজপুর শাখায় Web Development এর TUP-OFF-BDJ-29 ব্যাচের একজন ছাত্র। ১৮০ ঘন্টার ট্রেনিং নিয়ে এই প্রজেক্টটি সম্পন্ন করি। আমার অনেক ইচ্ছা ছিল Web Development ভালো করে শিখার, আমি অনেক জায়গায় শিখতেও গিয়েছিলাম, কিন্তু মনের মত প্রতিষ্ঠান ও ট্রেইনার না পাওয়ায় শিখা হয়ে উঠে নাই। অবশেষে আমি মনের মত ট্রেইনার পাই। এখান ভাতর্ি হওয়ার পর থেকে যা শিখছি আসলে তা লিখে বর্ননা করতে পারব না। আমার ট্রেইনার ছিলেন <a href="https://www.facebook.com/LuciferMorningstarTheDevil" style="overflow:hidden;display:inline;">সুমন গঙ্গোপধ্যায়</a> । উনার বুঝানোর ক্ষমতা এত সুন্দর যে, যে কেউ সহজেই বুঝে যাবে। ক্লাস সময় বাদেও যদি কোন সমস্যা পড়ি তাহলে উনাকে ফেসবুকে বা মোবাইলে সমস্যার কথা জানালে সমাধান পাওয়া যায়, ফলে চর্চা করার সময় কোন অসুবিধা হয় না এবং সময় ও নষ্ট হয় না। <br>
  আমি বেশি কিছু বলতে চাই না বলতে গেলে শেষ হবে না। বাংলাদেশ সরকারের আইসিটি মন্ত্রনালয়ের কাছে আমি আজীবন কৃতজ্ঞ থাকব এররকম একটা সুযোগ করে দেওয়ার জন্য। <br> আমি আশা রাখি এই প্রকল্পের মাধ্যমে যারা ট্রেনিং গ্রহণ করবে তারা জীবনে ভালো কিছু করতে পারবে এবং দেশের বেকারত্বের পরিমান থাকবে বলে মনে হয় না। <br> ধন্যবাদ সুমন স্যারকে, ধন্যবাদ বাংলাদেশ সরকারকে, ধন্যবাদ সকল ব্যাচমেটদেরকে।
  ভুল ত্রুটি ক্ষমা সুন্দর দৃষ্টিতে দেখবেন।

  আমি আজ গবর্িত আপরনার জন্য <a href="https://www.facebook.com/LuciferMorningstarTheDevil"style="overflow:hidden;display:inline;">সুমন স্যার </a> । </p>

</div>
<div class="footer">
 <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
</div>

  </body>
</html>
