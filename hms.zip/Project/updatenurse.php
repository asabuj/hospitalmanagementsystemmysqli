<?php
require('session.php');
 ?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT * FROM nurse WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $name=$row['name'];
    $blgroup=$row['bg'];
    $salary=$row['ms'];
    $age = $row['age'];
    $mobile = $row['mobile'];
    $mail = $row['mail'];
    $address = $row['address'];
    $bdob=$row['dob'];
    $jdate=$row['jdate'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);

//Update the data and Save it into the MySQL database;
include('dbconnect.php');
if (isset($_POST['submit'])) {
  $nname = $_POST['name'];
  $bloodgroup = $_POST['bg'];
  $monthsalary = $_POST['salary'];
  $mobile = $_POST['phone'];
  $email =$_POST['mail'];
  $address =$_POST['address'];
  $birthday =$_POST['bdate'];
  $page = $_POST['age'];
  $joindate =$_POST['jdate'];
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE nurse SET `name`='{$nname}', `bg` = '{$bloodgroup}', `ms` = '{$monthsalary}', `age`= '{$page}', `mobile` = '{$mobile}', `mail` = '{$email}', `address` = '{$address}', `dob` = '{$birthday}', `jdate` = '{$joindate}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'nurse.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Update Nurse</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/rabon.css">
    <link rel="stylesheet" href="css/stylephp.css">
    <script src="js/clock.js" charset="utf-8"></script>
    <script src="js/calander.js" charset="utf-8"></script>
    <script src="js/dob.js" charset="utf-8"></script>
    <script>
    $(document).ready(function(){

    $("#dob").change(function(){
       var value = $("#dob").val();
        var dob = new Date(value);
        var today = new Date();
        var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
        if(isNaN(age)) {

        // will set 0 when value will be NaN
         age=0;

        }
        else{
          age=age;
        }
        $('#age').val(age);

    });

});
</script>
</head>
<body onload="displayCalendar(),startTime()">
  <!--Hospital Name start-->
  <div class="name">
    <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
    <div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
    <h2>Hospital Management System</h2>
  </div>
  <!--Hospital Name End-->
  <!--1st header-->
  <div class="header">
      <div class="admin">

      </div>
      <div class="logout">
        <a href="home.php">Home</a>
        <a href="doctor.php">Doctor's</a>
        <a class= "active" href="nurse.php">Nurse</a>
        <a href="patient.php">Patient's</a>
        <a href="pharmacist.php">Pharamacist</a>
        <a href="labrotorist.php">Laboratist</a>
        <a href="accounts.php">Account's</a>
        <a href="profile.php">Profile</a>
        <a href="logout.php">Logout</a>
      </div>
  </div>
  <!--1st header end-->

  <!--Home page menue start-->
  <div class="menue">
    <a href="appoitmentlist.php">Appoinment</a>
    <a href="blood.php">Bloodbank</a>
    <a href="medicine.php">Medicine</a>
    <a href="operationlist.php">Operation's</a>
    <a href="birthreport.php">Birth Report</a>
    <a href="deathreport.php">Death Report</a>
    <a href="beddetails.php">Bed Status </a>
  </div>
  <!--Home page menue End-->
      <!--Analog Clock-->
      <div id="sabuj">
      <h1>Current Time</h1>
      <div id="a1"></div>
      </div>
      <!--Calander-->
      <div class="calander">

	<div id="calendar"></div>
</div>
<!-- Nurse Update-->
<div class="submenu">
  <a href="nurse.php">Back Nurse List</a>
</div>
<div class="non-semantic-protector">
        	<h1 class="ribbon">
        		<strong class="ribbon-content">Update Nurse</strong>
        	</h1>
  </div>
  <div class="main">
    <form class="form_div" action="#" method="post">
      <span>Nurse Name (নার্স নাম): </span>
      <input type="text" name="name" value="<?php echo $name;?>" placeholder="Nurse name" required>
      <span>BLood Group (রক্তের গ্রুপ):</span>
      <select class="sex" name="bg" value="<?php echo $bloodgorup;?>">
          <option>Blood Group</option>
          <option>A(+ve)</option>
          <option>A(-ve)</option>
          <option>B(+ve)</option>
          <option>B(-ve)</option>
          <option>AB(+ve)</option>
          <option>AB(-ve)</option>
          <option>O(+ve)</option>
          <option>O(-ve)</option>
      </select>
      <span>Monthly Salary (মাসিক বেতন):</span>
      <input type="number" name="salary" value="<?php echo $salary;?>" placeholder="Salary" required>
      <span>Mobile Number (মোবাইল নাম্বার):</span>
      <input type="number" name="phone" value="<?php echo $mobile;?>" required>
      <span>Personal Email (ব্যাক্তিগত মেইল):</span>
      <input type="email" name="mail" value="<?php echo $mail;?>" placeholder="Email" required>
      <span>Full Adress (স্থায়ী ঠিকানা): </span>
      <input type="text" name="address" value="<?php echo $address;?>" placeholder="Addres" required>
      <span>Date Of Birth: (জন্ম তারিখ)</span>
      <input type="date" id="dob" name="bdate" value="<?php echo $bdob;?>" placeholder="Date of Birth" required>
      <span>Age (বর্তমান বয়স)</span>
      <input type="number" id="age" name="age" value="<?php echo $age;?>" placeholder="Age" required>
      <span>Joining Date(যোগানের তারিখ): </span>
      <input type="date" name="jdate" value="<?php echo $jdate;?>" placeholder="Joining Date" required>
      <input type="submit" name="submit" value="Update" style="margin-left:40%;">
    </form>
  </div>
<!--footer Area-->
<div class="footer">
 <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="http://sabuj.bdonlinesolution.com">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
</div>
  </body>
</html>
