<?php
require('session.php');
 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Profile Management</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/rabon1.css">
    <script src="js/clock.js" charset="utf-8"></script>
    <script src="js/calander.js" charset="utf-8"></script>

</head>
  <body onload="displayCalendar(),startTime()" >
    <!--Hospital Name start-->
    <div class="name">
      <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
      <div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
      <h2>Hospital Management System</h2>
    </div>
    <!--Hospital Name End-->
    <!--1st header-->
      <div class="header">
          <div class="admin">
            <marquee behavior="alternate" scrollamount="2s"><h4><?php
            include('dbconnect.php');
              if (!mysqli_connect_errno()) {
                $query = "SELECT * FROM user WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);

                if($result){
                  echo "Current User:-".$row['username'];
                }
              }?></h4></marquee>
          </div>
          <div class="logout">
            <a href="home.php">Home</a>
            <a href="doctor.php">Doctor's</a>
            <a href="nurse.php">Nurse</a>
            <a href="patient.php">Patient's</a>
            <a href="pharmacist.php">Pharamacist</a>
            <a href="labrotorist.php">Laboratist</a>
            <a href="accounts.php">Account's</a>
            <a  class= "active" href="profile.php">Profile</a>
            <a href="logout.php">Logout</a>
          </div>
      </div>
      <!--1st header end-->

      <!--Home page menue start-->
      <div class="menue">
        <a href="#">Appoinment</a>
        <a href="blood.php">Bloodbank</a>
        <a href="medicine.php">Medicine</a>
        <a href="operationlist.php">Operation's</a>
        <a href="birthreport.php">Birth Report</a>
        <a href="deathreport.php">Death Report</a>
        <a href="beddetails.php">Bed Status </a>
      </div>
      <!--Home page menue End-->
      <!--Analog Clock-->
      <div id="sabuj">
      <h1>Current Time</h1>
      <div id="a1"></div>
      </div>
      <!--Calander-->
      <div class="calander">
      	<div id="calendar"></div>
      </div>
<div class="wellcome" style="margin-top:20px;margin-left:40%; width: 20%; border: 1px solid dodgerblue;">
  <?php
  include('dbconnect.php');
    if (!mysqli_connect_errno()) {
      $query = "SELECT * FROM user WHERE `visible` = 1";
      $result = mysqli_query($connection, $query);

      if($result){

      }
    }?>
  <p>Full Name: <?php echo $row['name']; ?><br> User id: <?php echo $row['username']; ?><br>Email: <?php echo $row['email']; ?></p><a href="profile.php">Back</a>
</div>
<div class="footer" style:"position:fixed; buttom:0;">
 <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
</div>

  </body>
</html>
