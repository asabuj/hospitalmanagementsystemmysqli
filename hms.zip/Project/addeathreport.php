<?php require('session.php'); ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Add Birth Report</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/rabon.css">
    <link rel="stylesheet" href="css/stylephp.css">
    <script src="js/clock.js" charset="utf-8"></script>
    <script src="js/calander.js" charset="utf-8"></script>
</head>
  <body onload="displayCalendar(),startTime()">
    <!--Hospital Name start-->
    <div class="name">
      <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
      <div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
      <h2>Hospital Management System</h2>
    </div>
    <!--Hospital Name End-->
    <!--1st header-->
    <div class="header">
        <div class="admin">
          <marquee behavior="alternate" scrollamount="2s"><h4><?php
          include('dbconnect.php');
            if (!mysqli_connect_errno()) {
              $query = "SELECT * FROM user WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);

              if($result){
                echo "Current User:-".$row['username'];
              }
            }?></h4></marquee>
        </div>
        <div class="logout">
          <a href="home.php">Home</a>
          <a href="doctor.php">Doctor's</a>
          <a href="nurse.php">Nurse</a>
          <a href="patient.php">Patient's</a>
          <a href="pharmacist.php">Pharamacist</a>
          <a href="labrotorist.php">Laboratist</a>
          <a href="accounts.php">Account's</a>
          <a href="profile.php">Profile</a>
          <a href="logout.php">Logout</a>
        </div>
    </div>
    <!--1st header end-->

    <!--Home page menue start-->
    <div class="menue">
      <a href="appoitmentlist.php">Appoinment</a>
      <a href="blood.php">Bloodbank</a>
      <a href="medicine.php">Medicine</a>
      <a href="operationlist.php">Operation's</a>
      <a href="birthreport.php">Birth Report</a>
      <a  class= "active" href="deathreport.php">Death Report</a>
      <a href="beddetails.php">Bed Status </a>
    </div>
    <!--Home page menue End-->
    <!--Analog Clock-->
    <div id="sabuj">
    <h1>Current Time</h1>
    <div id="a1"></div>
    </div>
      <!--Calander-->
      <div class="calander">
        <div id="calendar"></div>
      </div>

<!-- Add BirthReport-->
<div class="submenu">
  <a href="deathreport.php">Back DeathReport</a>
</div>
<div class="non-semantic-protector">
        	<h1 class="ribbon">
        		<strong class="ribbon-content">Create New Death Report</strong>
        	</h1>
</div>
<!--own immage-->
<div class="dev" style="float:left; margin-left:5%">
<h4 style="text-align:center;">Developer</h4>
     <img src="imge/sabuj.png" alt="" width:"200px" height="150px" style="border:1px solid lightgray; border-radius:50%;">
     <p><strong>Sabuj Chandra roy</strong><br>Beginer Web Developer</p>
   </div>
   <div class="dev" style="float:right; margin-right:5%">
     <h4 style="text-align:center;">My Honorable Trainer</h4>
     <img src="imge/suman.jpg" alt="" width:"200px" height="150px" style="border:1px solid lightgray; border-radius:50%;margin-left:20%;">
     <p><strong>Suman Gangopadhyay</strong><br>Trainer-Web Development,<strong>IIHT</strong></p>
   </div>
   <!--End imgage style-->
      <div class="main">
          <form class="form_div" action="#" method="post">
            <!--Insert Admit Patient Name for create Birthreport-->
            <?php
            include('dbconnect.php');
            echo "<span>"."Patient Name: "."</span>";
            echo "<select class= 'sex' name= 'name'>";
            echo '<option >'.'--- Select Patient Name ---'.'</option>';
            //$query=mysqli_query($con,"SELECT id,FirstName FROM persons");
            $query = mysqli_query($connection,"SELECT name FROM adpatient WHERE visible=1");
            $query_display = mysqli_query($connection,"SELECT * FROM adpatient WHERE visible=1");
            while($row=mysqli_fetch_array($query))
            {
                echo "<option ". $row['id']."'>".$row['name']
             .'</option>';
            }
            echo '</select>';
            ?>
            <span>Date of Birth:</span>
            <input type="date" name="dob" placeholder="Date of Birth">
            <span>Date of Death:</span>
            <input type="date" name="dod" placeholder="Date of Death">
            <span>Time of Death:</span>
            <input type="time" name="tdob" placeholder="Time of Birth">
            <span>Death of Cause</span>
            <input type="text" name="dcase" placeholder="Death of Cause">
            <span>Gender: </span>
            <select class="sex" name="sex">
                <option>Gender</option>
                <option>M</option>
                <option>F</option>
            </select>
            <span>Body Isuue: </span>
            <select class="sex" name="body">
                <option>Body Issue</option>
                <option>Yes</option>
                <option>No</option>
            </select>
            <input type="submit" name="save" value="Save Record" style="margin-left: 50%;">
          </form>
      </div>
      <!--Insert data table name birth_report database name : project-->
      <?php
      include('dbconnect.php');
      if (isset($_POST['save'])){
        $name = $_POST['name'];
        $ddob = $_POST['dob'];
        $ddod = $_POST['dod'];
        $tdob = $_POST['tdob'];
        $gender = $_POST['sex'];
        $contact = $_POST['dcase'];
        $issue = $_POST['body'];
        $sql_read = "SELECT `id` FROM death_report";
        $sl_no = 0;
        $result = mysqli_query($connection,$sql_read);
        while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
          $sl_no = $sl_no + 1;
        }
        $last_id = $sl_no;
        $last_id = $last_id + 1;
        $date = date('d-m-Y');
        $day=date("d",strtotime($date));
        $month=date("m",strtotime($date));
        $year=date("Y",strtotime($date));
        $whole_date=$year.$month.$day;
        $unique_id="D-".$whole_date.$last_id;
        if(!mysqli_connect_errno()){
          $visibility = 1;
          $query = "INSERT INTO `death_report` (`name`, `did`, `dob`, `dod`, `tod`, `dcase`,`sex`, `body_issue`, `visible`) VALUES('{$name}', '{$unique_id}', '{$ddob}', '{$ddod}', '{$tdob}','{$contact}', '{$gender}', '{$issue}', '{$visibility}')";
          if(mysqli_query($connection, $query)){
            echo "<b><script>alert('SUCCESS :  Added successfully');</script></b>";
            echo "<script>window.location.href = 'deathreport.php'</script>";
          }else{
            echo "Database Insert Failed";
          }
        }else{
          die("ERROR : ".mysqli_connect_errno());
        }
        mysqli_close($connection);
      }
       ?>
      <!--Footer Area-->
<div class="footer">
 <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="http://sabuj.bdonlinesolution.com">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
</div>
  </body>
</html>
