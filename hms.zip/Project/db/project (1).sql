-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2018 at 04:11 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `adpatient`
--

CREATE TABLE `adpatient` (
  `id` int(11) NOT NULL,
  `bed_id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `problem` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `age` varchar(10) DEFAULT NULL,
  `bloodgroup` varchar(10) DEFAULT NULL,
  `room` varchar(10) DEFAULT NULL,
  `bed` varchar(10) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `mobile` int(15) DEFAULT NULL,
  `jdate` date DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adpatient`
--

INSERT INTO `adpatient` (`id`, `bed_id`, `name`, `problem`, `gender`, `age`, `bloodgroup`, `room`, `bed`, `address`, `mobile`, `jdate`, `visible`, `ctime`) VALUES
(7, 0, 'Zakia ', 'High Fever', 'F', '22', 'B(+ve)', '2', '2', 'Dianpur', 123546987, '0000-00-00', '0', '2018-03-04 21:32:58'),
(8, 0, 'Sabuj Chandra Roy', 'High Fever', 'M', '25', 'A(+ve)', '125', 'H-2-3', 'Debiganj', 175489, '0000-00-00', '0', '2018-03-04 21:33:00'),
(9, 0, 'Barsha Saadiya', 'High Fever', 'F', '12', 'AB(-ve)', '12', 'H-3-2', 'Borobandar, Dinajpur', 1748154436, '0000-00-00', '0', '2018-03-04 21:33:02'),
(10, 0, 'PARVEZ', 'Head Ace', 'M', '14', 'AB(-ve)', '5', 'H-3-2', 'Balubari, Dinajpur', 1748154436, '0000-00-00', '0', '2018-03-04 21:33:03'),
(11, 0, 'MAHMUD', 'Mysql', 'M', '25', 'AB(+ve)', '12', 'H-2-3', 'Mumbai, India', 12548, '0000-00-00', '0', '2018-03-04 21:33:04'),
(12, 0, 'ROBIN', 'hpp', 'M', '23', 'O(-ve)', '23', 'H-3-5', 'Balubari, Dinajpur', 1254875985, '2018-02-16', '0', '2018-03-05 18:20:25'),
(17, 0, 'Jayanta Basak roy', 'Mysql', 'M', '12', 'AB(-ve)', '12', 'H-3-12', 'Balubari, Dinajpur', 1748154436, '2018-02-22', '0', '2018-02-19 09:08:41'),
(18, 1, 'Bapparaj', 'Endocrine system', 'Gender', '50', 'Blood Grou', '', 'SELECT * F', 'Dhaka', 1747896512, '2018-02-22', '0', '2018-03-07 19:52:29'),
(20, 0, 'Humayun Farid', 'xerosis', 'M', '64', 'A(+ve)', '17', 'H-3-8', 'Dhaka', 1254863258, '2018-02-08', '0', '2018-03-05 18:19:38'),
(22, 0, 'Joydev Kumar Rony', 'Teeth', 'M', '32', 'AB(+ve)', '12', 'B-3-4', 'Eidgah Bosti, Dinajpur', 1767034060, '2018-03-01', '1', '2018-03-05 19:27:47'),
(23, 2, 'Sajib Sarker', 'Headace', 'M', '20', 'A(+ve)', NULL, NULL, 'dinajpur', 1748154436, '2018-03-02', '1', '2018-03-07 18:16:16'),
(24, 1, 'Sabuj Chandra Roy', 'High Fever', 'M', '25', 'A(+ve)', NULL, NULL, 'dinajpur', 1748154436, '2018-03-07', '1', '2018-03-07 18:20:48'),
(25, 1, 'Swapan Kumar', 'High Fever', 'Gender', '12', 'Blood Grou', '', 'SELECT * F', 'Mumbai, India', 1754875985, '2018-03-01', '1', '2018-03-07 19:42:20'),
(26, 0, 'Tapos Kumar', 'Liver', 'M', '24', 'AB(+ve)', NULL, NULL, 'dinajpur', 1738555775, '2018-03-07', '1', '2018-03-07 18:43:41'),
(27, 1, 'Swapan Kumar', 'High Fever', 'M', '25', 'O(-ve)', NULL, NULL, 'Borobandar, Dinajpur', 1748154436, '2018-03-07', '1', '2018-03-07 18:45:39'),
(28, 3, 'Dipu Roy', 'High Fever', 'M', '25', 'AB(-ve)', NULL, NULL, 'Balubari, Dinajpur', 1748158478, '2018-03-06', '1', '2018-03-07 18:46:27'),
(29, 3, 'Sonjoy Kumar', 'High Presure', 'M', '25', 'B(-ve)', NULL, NULL, 'Balubari, Dinajpur', 1748154236, '2018-03-02', '1', '2018-03-07 18:47:29'),
(30, 1, 'Palash Sarker', 'High Presure', 'Gender', '25', 'Blood Grou', '', 'SELECT * F', 'Sadar, Thakurgaon', 2147483647, '2018-03-06', '1', '2018-03-07 19:44:48'),
(31, 1, 'Swapan Kumar', 'High Fever', 'Gender', '25', 'Blood Grou', '', 'SELECT * F', 'Mumbai, India 2', 1254875985, '2018-03-06', '1', '2018-03-07 19:44:07'),
(32, 5, 'Sujan Maleker', 'General', 'M', '15', 'A(+ve)', NULL, NULL, 'Dinajpur', 175215489, '2018-03-05', '1', '2018-03-07 19:31:36');

-- --------------------------------------------------------

--
-- Table structure for table `appoint`
--

CREATE TABLE `appoint` (
  `id` int(11) NOT NULL,
  `dname` varchar(50) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `fee` int(20) DEFAULT NULL,
  `vdate` date DEFAULT NULL,
  `vtime` time DEFAULT NULL,
  `gender` varchar(5) DEFAULT NULL,
  `commant` varchar(200) DEFAULT NULL,
  `appid` varchar(20) NOT NULL,
  `visible` varchar(5) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appoint`
--

INSERT INTO `appoint` (`id`, `dname`, `name`, `fee`, `vdate`, `vtime`, `gender`, `commant`, `appid`, `visible`, `ct`) VALUES
(24, 'Suman Gangapadyay', 'Apu Biswas', 2500, '2018-03-08', '12:12:00', 'F', 'NHP', 'APP-2018030418', '1', '2018-03-04 17:39:07'),
(25, 'Sabuj', 'Bapparaj', 1000, '2018-03-02', '22:12:00', 'M', 'Hard ', 'APP-201803042', '1', '2018-03-04 17:53:28'),
(26, 'Hamonta Kumar', 'ROBIN', 500, '2018-03-01', '12:45:00', 'M', 'Headace', 'APP-201803043', '1', '2018-03-04 17:56:20'),
(27, 'Dr. Partho Sarothi Roy', '--- Select Patient Name ---', 500, '2018-03-06', '12:02:00', 'M', 'Liver', 'APP-201803044', '1', '2018-03-04 17:58:15'),
(28, 'Hamonta Kumar', 'Samaira', 500, '2018-03-06', '12:04:00', 'M', 'PHP', 'APP-201803055', '1', '2018-03-04 18:00:48'),
(29, 'Prodip', 'Jayanta Basak roy', 700, '2018-03-07', '10:12:00', 'M', 'ICT', 'APP-201803056', '1', '2018-03-04 18:01:40'),
(30, 'Dr. Partho Sarothi Roy', 'Barsha Saadiya', 800, '2018-03-08', '14:45:00', 'M', 'Eye', 'APP-201803057', '1', '2018-03-04 18:02:44'),
(31, 'Jibon', 'SHUBRATA', 500, '2018-03-08', '09:10:00', 'M', 'High Fever', 'APP-201803058', '1', '2018-03-04 18:14:47'),
(32, 'Pobitra Kumar', 'PARVEZ', 500, '2018-03-09', '11:11:00', 'M', '', 'APP-201803059', '1', '2018-03-04 18:15:23'),
(33, 'Sabuj Chandra Roy', 'Zakia', 2000, '2018-03-07', '15:30:00', 'F', 'Project completion in PHP', 'APP-2018030610', '1', '2018-03-05 19:23:21'),
(34, 'Sabuj Chandra Roy', 'Joydev Kumar Rony', 2000, '2018-03-07', '16:30:00', 'F', 'Project completion in PHP', 'APP-2018030611', '1', '2018-03-05 19:28:53'),
(35, 'Dr. Partho Sarothi Roy', 'Humayun Farid', 500, '0000-00-00', '12:45:00', 'M', 'dd', 'APP-2018030812', '1', '2018-03-07 21:21:03'),
(36, 'Tapan Kumar Nath', 'Swapan Kumar', 500, '2018-03-10', '12:45:00', 'M', 'ddd', 'APP-2018030813', '1', '2018-03-07 21:23:29');

-- --------------------------------------------------------

--
-- Table structure for table `bed`
--

CREATE TABLE `bed` (
  `bed_id` int(11) NOT NULL,
  `bedname` varchar(50) DEFAULT NULL,
  `bedfee` float DEFAULT NULL,
  `seat` int(20) DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bed`
--

INSERT INTO `bed` (`bed_id`, `bedname`, `bedfee`, `seat`, `visible`, `ct`) VALUES
(1, 'ICU', 1500, 25, '1', '2018-03-07 17:18:37'),
(2, 'General', 500, 30, '1', '2018-03-07 17:19:54'),
(4, 'Emergency', 2000, 5, '1', '2018-03-07 18:37:39'),
(5, 'General 2', 500, 5, '1', '2018-03-07 18:41:02'),
(6, 'General 3', 500, 5, '1', '2018-03-07 18:42:17');

-- --------------------------------------------------------

--
-- Table structure for table `birth_r`
--

CREATE TABLE `birth_r` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dob` date DEFAULT NULL,
  `tdob` time DEFAULT NULL,
  `weight` varchar(20) DEFAULT NULL,
  `place` varchar(100) DEFAULT NULL,
  `f_name` varchar(50) DEFAULT NULL,
  `m_name` varchar(50) DEFAULT NULL,
  `bg` varchar(10) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `religion` varchar(30) DEFAULT NULL,
  `ref` varchar(30) DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `birth_r`
--

INSERT INTO `birth_r` (`id`, `name`, `dob`, `tdob`, `weight`, `place`, `f_name`, `m_name`, `bg`, `sex`, `religion`, `ref`, `visible`, `ct`) VALUES
(1, 'Suvosri ', '2018-02-09', '12:45:00', '50 Kg', 'Room No#15, DMC, Dhaka', 'Sharukh Khan', 'Gouri Sen', 'A(+ve)', 'F', 'Islam', 'DH-201802171', '1', '2018-02-16 22:30:25'),
(2, 'Abraham Khan Joy', '2018-02-09', '10:11:00', '60 Kg', 'Room No#15, DMC, Dhaka', 'Shakib Khan', 'Apu Biswas', 'A(-ve)', 'M', 'Islam', 'DH-201802172', '1', '2018-02-16 22:31:06'),
(3, 'Salman Khan', '2018-02-16', '12:45:00', '70 Kg', 'Room No#15, DMC, Dhaka', 'Amin Khan', 'Mouri', 'A(-ve)', 'M', 'Islam', 'DH-201802173', '1', '2018-02-16 22:32:14'),
(4, 'Somvu Khan', '2018-02-09', '12:12:00', '60 Kg', 'Birganj, Dinajpur-5200', 'Sabbir Khan', 'Reheana Akter', 'A(+ve)', 'M', 'Islam', 'DH-201802174', '1', '2018-02-16 21:39:06'),
(5, 'Mohona Ratlani', '2018-02-04', '22:12:00', '55 Kg', 'Kolkata, India', 'Jeetendra Madnani', 'Swastika Mukherjee', 'B(+ve)', 'F', 'Hindusim', 'DH-201802175', '1', '2018-02-16 22:38:37'),
(6, 'Amrita Roy', '2018-02-09', '22:12:00', '50 Kg', 'Thakurgaon', 'Brojobasi', 'Sephali ', 'B(+ve)', 'M', 'Hindusim', 'DH-201802176', '1', '2018-02-17 09:57:26');

-- --------------------------------------------------------

--
-- Table structure for table `blood_details`
--

CREATE TABLE `blood_details` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `ddate` date NOT NULL,
  `dtime` time NOT NULL,
  `age` int(10) NOT NULL,
  `blood_group` varchar(20) NOT NULL,
  `total_num` int(11) NOT NULL,
  `last_update_use` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `used_num` int(11) NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood_details`
--

INSERT INTO `blood_details` (`id`, `name`, `ddate`, `dtime`, `age`, `blood_group`, `total_num`, `last_update_use`, `used_num`, `last_update`) VALUES
(1, '', '0000-00-00', '00:00:00', 0, 'A (+ve)', 4, '2018-03-05 21:46:15', 20, '2018-03-05 21:46:15'),
(2, '', '0000-00-00', '00:00:00', 0, 'A (-ve)', 0, '2018-03-05 21:46:16', 7, '2018-03-05 21:46:16'),
(3, '', '0000-00-00', '00:00:00', 0, 'B (+ve)', 1, '2018-03-05 21:46:18', 1, '2018-03-05 21:46:18'),
(4, '', '0000-00-00', '00:00:00', 0, 'B (-ve)', 0, '2018-03-05 21:46:20', 10002, '2018-03-05 21:46:20'),
(7, '', '0000-00-00', '00:00:00', 0, 'AB (+ve)', 0, '2018-03-05 21:46:21', 1, '2018-03-05 21:46:21'),
(8, '', '0000-00-00', '00:00:00', 0, 'AB (-ve)', 0, '2018-03-05 21:46:22', 1, '2018-03-05 21:46:22'),
(11, '', '0000-00-00', '00:00:00', 0, 'O (+ve)', 0, '2018-03-05 21:46:25', 1, '2018-03-05 21:46:25'),
(12, '', '0000-00-00', '00:00:00', 0, 'O (-ve)', 0, '2018-03-05 21:46:27', 1, '2018-03-05 21:46:27');

-- --------------------------------------------------------

--
-- Table structure for table `death_report`
--

CREATE TABLE `death_report` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `did` varchar(50) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `dod` date DEFAULT NULL,
  `tod` time DEFAULT NULL,
  `dcase` varchar(300) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `body_issue` varchar(10) DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `death_report`
--

INSERT INTO `death_report` (`id`, `name`, `did`, `dob`, `dod`, `tod`, `dcase`, `sex`, `body_issue`, `visible`, `ct`) VALUES
(1, 'ROBIN', 'D-201803051', '1989-03-14', '2018-03-01', '22:12:00', 'Malariya', 'M', 'Yes', '1', '2018-03-04 22:54:54'),
(2, 'SHUBRATA', 'D-201803052', '1971-03-01', '2018-02-21', '22:45:00', 'Fiver', 'M', 'Yes', '1', '2018-03-04 22:55:46'),
(3, 'Samaira', 'D-201803053', '1974-03-07', '2018-03-04', '10:10:00', 'HighPresure', 'F', 'Yes', '1', '2018-03-04 22:56:45'),
(4, 'Bapparaj', 'D-201803054', '1964-03-01', '2017-02-08', '02:14:00', 'Cancer', 'M', 'Yes', '1', '2018-03-04 22:57:24'),
(5, 'Apu Biswas', 'D-201803055', '1988-03-02', '2018-03-02', '12:12:00', 'Cancer', 'M', 'Yes', '1', '2018-03-04 22:57:56');

-- --------------------------------------------------------

--
-- Table structure for table `doclog`
--

CREATE TABLE `doclog` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `special` varchar(30) DEFAULT NULL,
  `mail` varchar(50) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doclog`
--

INSERT INTO `doclog` (`id`, `name`, `special`, `mail`, `username`, `password`, `visible`, `ct`) VALUES
(1, 'Sabuj Chandra Roy', 'Cardiology', 'sabuj@gmail.com', '', '123456', '1', '2018-02-17 21:06:08'),
(2, 'Sabuj Chandra Roy', 'Colorectal Surgery', 'sonia@gmail.com', 'sabuj', '123456', '1', '2018-02-17 21:11:54'),
(3, 'Sabuj Roy', 'Colorectal Surgery', 'sabujroy@gmail.com', 'sabujr', '123456', '1', '2018-02-27 19:02:48'),
(4, 'Doctor', 'Gastroenterology', 'sss@gmail.com', 'abc', 'abc', '1', '2018-02-28 09:25:41'),
(5, 'Suman', 'Neurologist', 'sabujroy@gmail.com', 'sss', '123456', '1', '2018-02-28 09:35:48'),
(6, 'Suman', 'Cardiology', 'suman@gmail.com', 'suman', '123456', '1', '2018-02-28 19:17:02'),
(7, 'Suman Gangapadyay', 'Cardiology', 'suman12@gmail.com', 'suman12', '123456', '1', '2018-03-04 12:39:48');

-- --------------------------------------------------------

--
-- Table structure for table `labrotorist`
--

CREATE TABLE `labrotorist` (
  `id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `department` varchar(30) DEFAULT NULL,
  `dtime` varchar(30) DEFAULT NULL,
  `dday` varchar(30) DEFAULT NULL,
  `salary` int(20) DEFAULT NULL,
  `mobile` int(20) DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `labrotorist`
--

INSERT INTO `labrotorist` (`id`, `name`, `department`, `dtime`, `dday`, `salary`, `mobile`, `visible`, `ct`) VALUES
(1, 'Swapan Kumar', 'ICU', '1PM to 5PM', 'Everyday', 10000, 125489, '1', '2018-02-11 18:30:01'),
(2, 'Jayanta Basak', 'Diagnostic', '2PM to 10PM', 'Sun, Tue, Wed, Fri', 10000, 1723158064, '1', '2018-03-05 19:04:52'),
(3, 'Amrita Roy', 'Radiotherapy', '10PM to 6AM', 'Sun, Tue, Wed, Fri', 12000, 2154879, '0', '2018-03-05 19:07:09'),
(4, 'Sombu Khan', 'Radiotherapy', '10PM to 6AM', 'Sun, Tue, Wed, Fri', 125000, 1748154436, '1', '2018-02-17 11:06:54'),
(5, 'Gouri Sen', 'Radiotherapy', '2PM to 10PM', 'Every Day', 20000, 18245789, '1', '2018-03-04 18:17:08'),
(6, 'Sumi Akter', 'Diagnostic', '2PM to 10PM', 'Sun, Tue, Wed, Fri', 12000, 1825498, '1', '2018-03-04 18:17:50'),
(7, 'Soma khan', 'Ophthalmology', '10PM to 6AM', 'Sat, Mon, Thu', 12000, 185246987, '1', '2018-03-04 18:18:20'),
(8, 'Tapos Kumar', 'Ophthalmology', '6AM to 2Pm', 'Sun, Tue, Wed, Fri', 12000, 1738555775, '1', '2018-03-04 18:30:24');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `id` int(11) NOT NULL,
  `mname` varchar(30) DEFAULT NULL,
  `catagory` varchar(50) DEFAULT NULL,
  `genric` varchar(30) DEFAULT NULL,
  `shelf` varchar(30) DEFAULT NULL,
  `unit` varchar(30) DEFAULT NULL,
  `quantity` varchar(30) DEFAULT NULL,
  `pprice` int(10) DEFAULT NULL,
  `sprice` int(20) DEFAULT NULL,
  `edate` date DEFAULT NULL,
  `supliername` varchar(50) DEFAULT NULL,
  `phaname` varchar(50) DEFAULT NULL,
  `mid` varchar(15) NOT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`id`, `mname`, `catagory`, `genric`, `shelf`, `unit`, `quantity`, `pprice`, `sprice`, `edate`, `supliername`, `phaname`, `mid`, `visible`, `ct`) VALUES
(1, 'NapaExtra', 'tablet', 'General', 'B-3', 'Box', '10', 350, 450, '2022-02-23', 'Squre', 'Ripon Rana', 'M-2018030511', '1', '2018-03-04 21:11:02'),
(2, 'AcePlus', 'tablet', 'General', 'A2', 'Box', '10', 350, 450, '2022-02-21', 'Squre', 'Subas Roy', 'M-2018030502', '1', '2018-03-04 21:11:25'),
(3, 'Tuska', 'Shirap', 'General', 'B-3', 'Milli liter(ml)', '200', 300, 350, '2022-02-15', 'Squre', 'Sabuj Chandra Roy', 'M-2018030505', '1', '2018-03-04 21:11:36'),
(4, 'Sechlo', 'tablet', 'General', 'B-5', 'Piece (Pc)', '100', 450, 500, '2022-02-28', 'Squre', 'Subas Roy', 'M-2018030508', '1', '2018-03-04 21:11:50'),
(5, 'Tophen', 'tablet', 'General', 'B-9', 'Box', '12', 500, 600, '2025-02-22', 'Bexcinko', 'Sabuj Chandra Roy (Diagnostic)', 'M-2018030509', '1', '2018-03-04 21:12:03'),
(6, 'Napa', 'tablet', 'General', 'A-4', 'Box', '15', 1200, 1400, '2018-02-22', 'ACE', 'Tapos Kumar (Maternity)', 'M-2018030510', '1', '2018-03-04 21:12:11'),
(12, 'Aspering', 'tablet', 'Paracitamol BP', 'B 4', 'Box', '12', 450, 550, '2021-03-21', 'Squre (Mahamud)', 'Dev barman (ICU)', 'M-2018030412', '1', '2018-03-04 21:12:35'),
(13, 'Ziloric', 'tablet', 'Allopurinol', '10', 'Piece (Pc)', '10', 35, 40, '0000-00-00', 'Wellcome Group', 'Sabuj Chandra Roy (Diagnostic)', 'M-2018030413', '1', '2018-03-04 21:12:49'),
(14, 'Histasin', 'tablet', 'Parasitamol', 'A-5', 'Box', '10', 500, 550, '2022-03-20', 'Squre', 'Arun Dev Barman (Emergency)', 'M-2018030514', '1', '2018-03-04 21:13:02'),
(15, 'BComplex', 'tablet', 'Vitamin', 'A-6', 'Milli liter(ml)', '1000', 120, 150, '2019-03-13', 'Squre', 'Prosenjeet kumar (Ophthalmology)', 'M-2018030515', '1', '2018-03-04 21:13:08'),
(16, 'BComplex', 'Tablet', 'Parasitamol', 'A-5', 'Piece (Pc)', '10', 1200, 1300, '2019-03-06', 'Squre', 'Rahul Ray (Maternity)', 'M-2018030516', '1', '2018-03-04 21:06:23');

-- --------------------------------------------------------

--
-- Table structure for table `med_ca`
--

CREATE TABLE `med_ca` (
  `id` int(11) NOT NULL,
  `catagoryname` varchar(50) DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `med_ca`
--

INSERT INTO `med_ca` (`id`, `catagoryname`, `visible`, `ct`) VALUES
(1, 'Tablet', '1', '2018-02-19 14:47:48'),
(2, 'Capsul', '1', '2018-02-19 14:48:13'),
(3, 'Injection', '1', '2018-02-19 14:48:26'),
(4, 'Vaccine', '1', '2018-02-19 14:51:20'),
(5, 'Colforsin', '1', '2018-02-19 14:51:43'),
(6, 'Shirap', '1', '2018-02-19 14:52:56');

-- --------------------------------------------------------

--
-- Table structure for table `newdoctor`
--

CREATE TABLE `newdoctor` (
  `id` int(11) NOT NULL,
  `dname` varchar(30) DEFAULT NULL,
  `ql` varchar(30) DEFAULT NULL,
  `sp` varchar(30) DEFAULT NULL,
  `bg` varchar(30) DEFAULT NULL,
  `gn` varchar(20) DEFAULT NULL,
  `salary` int(30) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `mobile` int(20) DEFAULT NULL,
  `mail` varchar(30) DEFAULT NULL,
  `address` text,
  `dob` date DEFAULT NULL,
  `jdate` date DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newdoctor`
--

INSERT INTO `newdoctor` (`id`, `dname`, `ql`, `sp`, `bg`, `gn`, `salary`, `age`, `mobile`, `mail`, `address`, `dob`, `jdate`, `visible`, `ctime`) VALUES
(1, 'SABUJ CHANDRA ROY', 'MBBS', '', 'A (+ve)', 'Gender', 50000, 28, 1719470043, 'roysabujchandra@gmail.com', 'Balubari, Dinajpur', '1991-12-25', '2018-02-06', '0', '2018-02-07 16:31:51'),
(2, 'Sabuj chandra Roy', 'MBBS', '', 'A(-ve)', 'Gender', 50000, 27, 1719470043, 'roysabujchandra@gmail.com', 'Brobandor, Dinajpur', '2018-12-25', '2018-02-02', '0', '2018-02-09 18:18:28'),
(3, 'Hamonta Kumar', 'FCPS(Gynae)', 'Paediatrics', 'A(-ve)', 'M', 450000, 26, 1723158094, 'hamanto@gmail.com', 'Borobandar, Dinajpur', '1991-10-04', '2018-02-05', '1', '2018-03-05 17:26:57'),
(4, 'Ripon', 'MBS', 'Medicin', 'A(-ve)', 'M', 521235, 12, 12, 'roysabujchandra@gmail.com', 'dddd', '0000-00-00', '0000-00-00', '0', '2018-03-04 17:06:52'),
(5, 'Gobindo Roy', 'MBBS', 'Medicin', 'A(-ve)', 'M', 52000, 25, 12457859, 'gobindo@gmail.com', 'Fulbari, Dinajpur', '0000-00-00', '0000-00-00', '0', '2018-03-04 17:06:50'),
(6, 'Jibon Barman', 'FCBS', 'Eyeist', 'A (+ve)', 'M', 25000, 24, 2147483647, 'jibon@gmail.com', 'Dinajpur', '2018-02-23', '2018-02-22', '0', '2018-02-17 10:22:20'),
(7, 'Sabuj Chandra Roy', 'FCPS(Medicine)', 'Medicine', 'A(+ve)', 'M', 50000, 26, 1719470043, 'sabuj@gmail.com', 'dinajpur', '1991-12-25', '2018-02-22', '1', '2018-03-05 19:18:22'),
(8, 'Prodip  Kumar', 'MD(Ped)', 'Psychiatry', 'O(+ve)', 'M', 10000, 22, 1715235698, 'prodip@gmail.com', 'PTI, Dinajpur', '1994-02-02', '2018-02-07', '1', '2018-03-05 19:22:01'),
(9, 'Subas Pal', 'MD(Child Health)', 'Cardiology', 'B(-ve)', 'M', 5, 45, 123456987, 'hrm@gmail.com', 'Brobandor, Dinajpur', '0000-00-00', '0000-00-00', '0', '2018-02-17 10:22:33'),
(10, 'Jibon', 'FCPS(Surgery)', 'Medicine', 'AB(-ve)', 'M', 25000, 25, 12548, 'dd@gmail.com', 'Debiganj', '2018-02-20', '2018-02-22', '1', '2018-02-19 09:00:43'),
(11, 'Dr. Partho Sarothi Roy', 'PGT(SSHMCH)', 'Neurologist', 'A(+ve)', 'M', 50000, 35, 1245896358, 'parthosahrothi@gmail.com', 'Mirpur, Dhaka-1200', '1985-02-06', '2018-02-07', '1', '2018-02-21 23:17:23'),
(12, 'Suman Gangapadyay', 'FCPS(Gynae)', 'Nephrology', 'O(+ve)', 'M', 100000, 34, 162548960, 'suman12@gmail.com', 'Mumbai, India', '2018-03-13', '2018-03-01', '1', '2018-03-04 16:30:55'),
(13, 'Robin', 'PGT(SSHMCH)', 'Neurologist', 'A(+ve)', 'M', 150000, 28, 172548975, 'robin@gmail.com', 'Dinajpur', '1989-12-12', '2018-03-01', '0', '2018-03-04 17:06:42'),
(14, 'Akash kumar', 'PGT(SSHMCH)', 'Spinal Surgery', 'Blood Group', 'M', 1254012, 0, 1745879, 'akash@gmail.com', 'Mumbai, India', '1989-03-06', '2018-02-27', '0', '2018-03-04 17:06:31'),
(15, 'Somaru', 'MCPS', 'Obstetrics', 'AB(+ve)', 'F', 50000, 0, 174587985, 'somaru@gmail.com', 'Dinajpur', '1995-03-19', '2018-03-08', '0', '2018-03-04 17:06:28'),
(16, 'Pobitra Kumar', 'MD(Child Health)', 'Obstetrics', 'B(+ve)', 'F', 2510000, 32, 174587526, 'pobotra@gmail.com', 'Dinajpur', '1985-03-06', '2018-03-20', '0', '2018-03-05 17:27:09'),
(17, 'Monoranjon Dev Shorma', 'PGT(SSHMCH)', 'Neurologist', 'A(+ve)', 'M', 35000, 27, 1723568478, 'devsharma@gmail.com', 'Kosbha, Dinajpur', '1991-03-02', '2018-03-01', '1', '2018-03-05 17:28:22'),
(18, 'Tapan Kumar Nath', 'MS(Urology)', 'Neurologist', 'A(+ve)', 'M', 45000, 43, 174725954, 'nath@gmail.com', 'Dinajpur', '1975-03-07', '2018-03-06', '1', '2018-03-07 21:00:15'),
(19, 'Dr. Partho Boruya', 'PGT(SSHMCH)', 'Neurologist', 'A(+ve)', 'M', 45000, 28, 17582659, 'partho@yahoo.com', 'Dinajpur', '1989-03-09', '2018-03-07', '1', '2018-03-07 21:09:39');

-- --------------------------------------------------------

--
-- Table structure for table `nurse`
--

CREATE TABLE `nurse` (
  `id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `bg` varchar(10) DEFAULT NULL,
  `ms` int(20) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `mobile` int(20) DEFAULT NULL,
  `mail` varchar(50) DEFAULT NULL,
  `address` text,
  `dob` date DEFAULT NULL,
  `jdate` date DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nurse`
--

INSERT INTO `nurse` (`id`, `name`, `bg`, `ms`, `age`, `mobile`, `mail`, `address`, `dob`, `jdate`, `visible`, `ct`) VALUES
(1, 'Zakia', 'AB(-ve)', 12000, 20, 123456789, 'zakia@yahoo.com', 'Dinajpur', '0000-00-00', '0000-00-00', '0', '2018-02-21 21:43:46'),
(2, 'Monisha Khatun', 'B(+ve)', 13000, 18, 123456789, 'monishia@gmail.com', 'Brobandor, Dinajpur', '0000-00-00', '0000-00-00', '0', '2018-03-04 21:33:23'),
(3, 'Sonia Akter', 'AB(-ve)', 13000, 17, 214569874, 'sonia@gmail.com', 'Dinajpur', '1995-02-14', '2018-02-04', '0', '2018-02-21 21:51:31'),
(4, 'Sonali Akter', 'A(+ve)', 12000, 12, 172569, 'sonia@gmail.com', 'Dinajp', '2018-02-08', '2018-02-22', '0', '2018-02-21 21:37:33'),
(5, 'Singdha Khan', 'A(+ve)', 12000, 18, 1254789653, 'singdha@ymail.com', 'Birganj', '1999-02-01', '2018-02-14', '0', '2018-02-21 21:35:06'),
(6, 'Arpita Banu', 'A(-ve)', 15000, 19, 12548796, 'banu@gmail.com', 'Birganj', '1998-02-14', '2018-02-15', '1', '2018-02-21 22:29:58'),
(7, 'Sony akter', 'B(+ve)', 14000, 25, 1823659874, 'sonai@gmail.com', '15000', '1993-02-02', '2018-02-14', '1', '2018-03-05 17:56:41'),
(8, 'Anamika Akter', 'A(+ve)', 12000, 18, 1245789652, 'anamika@gmail.com', 'Dinajpur', '2001-02-15', '2018-02-14', '1', '2018-02-22 09:46:46'),
(9, 'Jahanara Khatun', 'A(+ve)', 14000, 14, 1245879534, 'hatun@gmail.com', 'Dinajpur', '2014-02-07', '2018-02-14', '1', '2018-02-22 09:48:19'),
(10, 'Monika Khatun', 'A(-ve)', 25000, 22, 182536589, 'khatunmonika@yahoo.com', 'Munshipara, Dinajpur', '1995-03-08', '2018-03-01', '1', '2018-03-05 17:32:38'),
(11, 'Dwipa Roy', 'B(-ve)', 12000, 26, 1747236534, 'roydwipa@yahoo.com', 'Birganj, Dinajpur', '1992-03-01', '2018-03-02', '1', '2018-03-05 18:01:27');

-- --------------------------------------------------------

--
-- Table structure for table `opera`
--

CREATE TABLE `opera` (
  `id` int(11) NOT NULL,
  `sid` varchar(20) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `oname` varchar(50) DEFAULT NULL,
  `fee` int(12) DEFAULT NULL,
  `odate` date DEFAULT NULL,
  `otime` time DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `opera`
--

INSERT INTO `opera` (`id`, `sid`, `name`, `oname`, `fee`, `odate`, `otime`, `visible`, `ct`) VALUES
(1, 'OP-201802181', 'Hamanta Kumar', 'Eye Operation', 1200, '2018-02-24', '12:04:00', '1', '2018-02-17 20:04:56'),
(2, 'OP-201802182', 'Sabuj Chandra Roy', 'Tumer', 2000, '2018-02-16', '12:45:00', '1', '2018-02-17 20:06:16'),
(3, 'OP-201802193', 'Samaira', 'Tumer', 2000, '2018-02-24', '02:02:00', '1', '2018-02-18 21:36:15'),
(4, 'OP-201802214', 'PARVEZ', 'Heart Surgery', 3000, '2018-02-23', '12:45:00', '1', '2018-02-20 18:52:20'),
(5, 'OP-201802215', 'Humayun Farid', 'Heart Surgery', 3000, '2018-02-23', '22:12:00', '1', '2018-02-20 19:13:52'),
(6, 'OP-201802216', 'Bapparaj', 'Liver Operation', 6000, '2018-02-27', '12:45:00', '1', '2018-02-20 19:14:20'),
(7, 'OP-201802217', 'MOHAMMAD', 'Kindy', 30000, '2018-02-26', '12:45:00', '1', '2018-02-20 19:14:47'),
(8, 'OP-201802218', 'Apu Biswas', 'Sizer', 12000, '2018-02-23', '12:45:00', '1', '2018-02-20 19:15:20'),
(9, 'OP-201802219', 'SHUBRATA', 'Eye Operation', 15000, '2018-03-01', '00:45:00', '1', '2018-02-20 19:15:46'),
(10, 'OP-2018022110', 'MAHMUD', 'Liver Operation', 20000, '2018-03-02', '00:45:00', '1', '2018-02-20 19:16:20');

-- --------------------------------------------------------

--
-- Table structure for table `pers`
--

CREATE TABLE `pers` (
  `id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `vdate` date DEFAULT NULL,
  `problem` varchar(100) DEFAULT NULL,
  `test` varchar(100) DEFAULT NULL,
  `ref` varchar(30) DEFAULT NULL,
  `nday` date DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pers`
--

INSERT INTO `pers` (`id`, `name`, `age`, `vdate`, `problem`, `test`, `ref`, `nday`, `visible`, `ct`) VALUES
(1, 'sabuj', 12, '2018-02-09', '122', '125', NULL, '2018-02-07', '1', '2018-02-15 17:08:25'),
(2, 'Tapos Kumar', 12, '2018-02-15', 'asd', 'sdf', NULL, '2018-02-20', '1', '2018-02-16 08:00:42'),
(3, 'Shanto', 25, '2018-02-08', 'no', 'no', NULL, '2018-02-21', '1', '2018-02-16 09:17:04'),
(4, 'Zakia Khanam', 24, '2018-02-16', 'Onek', 'Sleep test', NULL, '2018-02-22', '1', '2018-02-16 10:07:52'),
(5, 'Sabuj Chandra Roy', 25, '2018-02-16', 'Head Ace with PHP', 'Rest for 24 hours', NULL, '2018-02-21', '1', '2018-02-16 11:43:45'),
(6, 'Katrina Kaif', 32, '2018-02-16', 'Smoking', 'Kidny', 'PRE-201802166', '2018-02-22', '1', '2018-02-16 16:00:57'),
(7, 'Sabuj Chandra Roy', 24, '2018-02-17', 'Head Ace', 'Jquery Test', 'PRE-201802177', '2018-02-22', '1', '2018-02-16 23:19:45'),
(8, 'babli', 11, '2018-02-22', 'ddd', 'dd', 'PRE-201802198', '2018-02-28', '1', '2018-02-18 21:47:25'),
(9, 'nai', 55, '2018-02-21', 'dddd', 'dd', 'PRE-201802199', '2018-02-22', '1', '2018-02-18 22:15:48');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacist`
--

CREATE TABLE `pharmacist` (
  `id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `department` varchar(30) DEFAULT NULL,
  `dtime` varchar(30) DEFAULT NULL,
  `dday` varchar(30) DEFAULT NULL,
  `salary` int(20) DEFAULT NULL,
  `mobile` int(20) DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pharmacist`
--

INSERT INTO `pharmacist` (`id`, `name`, `department`, `dtime`, `dday`, `salary`, `mobile`, `visible`, `ct`) VALUES
(1, 'Sabuj Chandra Roy', 'Diagnostic', '1PM to 5PM', 'Everyday', 12000, 17254689, '1', '2018-02-11 18:08:31'),
(2, 'Tapos Kumar', 'Maternity', '5PM to 10 PM', 'Everyday', 12000, 2147483647, '1', '2018-02-11 18:21:00'),
(3, 'Ripon Rana', 'Diagnostic', '2PM to 10PM', 'Every Day', 10000, 2147483647, '1', '2018-02-11 18:41:06'),
(4, 'Subas Roy', 'Ophthalmology', '2PM to 10PM', 'Sat, Mon, Thu', 12000, 12544887, '1', '2018-02-17 11:04:36'),
(5, 'Shakib Khan', 'Emergency', '2PM to 10PM', 'Every Day', -2500, 5458514, '0', '2018-03-05 18:30:44'),
(6, 'Joba Rani', 'Emergency', '2PM to 10PM', 'Sun, Tue, Wed, Fri', 2500, 12545698, '1', '2018-02-19 19:40:43'),
(7, 'Amin Khan', 'Diagnostic', '2PM to 10PM', 'Sat, Mon, Thu', 12548, 12548963, '1', '2018-02-19 19:41:08'),
(8, 'Salman Khan', 'Radiotherapy', '2PM to 10PM', 'Sat, Mon, Thu', 25896, 1236985147, '1', '2018-02-19 19:41:34'),
(9, 'Suvo jeet', 'ICU', '6AM to 2Pm', 'Sun, Tue, Wed, Fri', 1254896, 225555555, '1', '2018-02-19 19:41:58'),
(10, 'Prosenjeet kumar roy', 'Ophthalmology', '2PM to 10PM', 'Every Day', 12000, 174889665, '1', '2018-03-05 18:48:34'),
(11, 'Shuvom Chaterjee', 'Emergency', '2PM to 10PM', 'Sun, Tue, Wed, Fri', 25000, 12548963, '1', '2018-02-19 19:43:01'),
(12, 'Miali Mishra', 'Neurology', '10PM to 6AM', 'Sat, Mon, Thu', 12000, 1236987456, '1', '2018-02-19 19:43:34'),
(13, 'Rahul Ray', 'Maternity', '10PM to 6AM', 'Sat, Mon, Thu', 120000, 123654789, '1', '2018-02-19 19:44:16'),
(14, 'Dev barman', 'ICU', '10PM to 6AM', 'Every Day', 123000, 1236598745, '1', '2018-02-19 19:45:00'),
(15, 'Arun Dev Barman', 'Emergency', '6AM to 2Pm', 'Every Day', 12000, 123659874, '1', '2018-02-19 19:50:00');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` int(11) NOT NULL,
  `sid` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `tname` varchar(30) DEFAULT NULL,
  `fee` int(20) DEFAULT NULL,
  `tdate` date DEFAULT NULL,
  `visible` varchar(20) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `sid`, `name`, `tname`, `fee`, `tdate`, `visible`, `ct`) VALUES
(1, 'TE-201802181', 'Barsha Saadiya', 'BLood', 1548, '2018-02-21', '1', '2018-02-17 22:02:32'),
(2, 'TE-201802182', 'MAHMUD', 'Exray', 1500, '2018-02-20', '1', '2018-02-17 22:04:26'),
(3, 'TE-201802193', 'ROBIN', 'Exray', 1500, '2018-02-23', '1', '2018-02-18 21:36:58');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `ct` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `username`, `password`, `visible`, `ct`) VALUES
(1, 'Sabuj Chandra Roy', 'sabuj@gmail.com', 'sabuj', 'sabuj', '1', '2018-02-26 22:32:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adpatient`
--
ALTER TABLE `adpatient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appoint`
--
ALTER TABLE `appoint`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bed`
--
ALTER TABLE `bed`
  ADD PRIMARY KEY (`bed_id`);

--
-- Indexes for table `birth_r`
--
ALTER TABLE `birth_r`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blood_details`
--
ALTER TABLE `blood_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `death_report`
--
ALTER TABLE `death_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doclog`
--
ALTER TABLE `doclog`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mail` (`mail`,`username`);

--
-- Indexes for table `labrotorist`
--
ALTER TABLE `labrotorist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `med_ca`
--
ALTER TABLE `med_ca`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newdoctor`
--
ALTER TABLE `newdoctor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nurse`
--
ALTER TABLE `nurse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `opera`
--
ALTER TABLE `opera`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pers`
--
ALTER TABLE `pers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pharmacist`
--
ALTER TABLE `pharmacist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adpatient`
--
ALTER TABLE `adpatient`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `appoint`
--
ALTER TABLE `appoint`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `bed`
--
ALTER TABLE `bed`
  MODIFY `bed_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `birth_r`
--
ALTER TABLE `birth_r`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `blood_details`
--
ALTER TABLE `blood_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `death_report`
--
ALTER TABLE `death_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `doclog`
--
ALTER TABLE `doclog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `labrotorist`
--
ALTER TABLE `labrotorist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `med_ca`
--
ALTER TABLE `med_ca`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `newdoctor`
--
ALTER TABLE `newdoctor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `nurse`
--
ALTER TABLE `nurse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `opera`
--
ALTER TABLE `opera`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pers`
--
ALTER TABLE `pers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `pharmacist`
--
ALTER TABLE `pharmacist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
