
<!--read data from table blood, database project-->
<?php
include('dbblood.php');
if (isset($_POST['added_bag'])){
  $row_id = $_GET['id'];
  $name =$_POST['name'];
  $ddate = $_POST['ddate'];
  $dtime = $_POST['dtime'];
  $age = $_POST['age'];
  $group = $_POST['bg'];
  $amount = $_POST['bag_num'];
  if(!mysqli_connect_errno()){
    $visibility = 1;
    $query = "INSERT INTO `blood_details` (`name`, `ddate`, `dtime`, `age`, `blood_group`, `total_num`, `used_num`) VALUES('{$name}', '{$ddate}','{$dtime}', '{$age}', '{$group}','{$amount}' ,'{$visibility}')";
    if(mysqli_query($connection, $query)){
      //echo "<b><script>alert('SUCCESS : Blood Added successfully');</script></b>";
      echo "<script>window.location.href = 'adblood.php'</script>";
    }
  }
  mysqli_close($connection);
}
?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Add Blood</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/clock.css">
    <link rel="stylesheet" href="css/rabon1.css">
    <link rel="stylesheet" href="css/stylephp.css">
    <script src="js/clock.js" charset="utf-8"></script>
    <script src="js/calander.js" charset="utf-8"></script>
</head>
  <body onload="displayCalendar(),startTime()">
    <!--Hospital Name start-->
    <div class="name">
      <h2>Hospital Management System</h2>
    </div>
    <!--Hospital Name End-->
    <!--1st header-->
      <div class="header">

          <div class="admin">
            <marquee behavior="alternate" scrollamount="2s"><h1>Hello Admin!</h1></marquee>
          </div>
          <div class="logout">
            <a href="">Event</a>
            <a href="home.php">Home</a>
            <a href="doctor.php">Doctor's</a>
            <a href="nurse.php">Nurse</a>
            <a href="patient.php">Patient's</a>
            <a href="pharmacist.php">Pharamacist</a>
            <a href="labrotorist.php">Laboratist</a>
            <a href="#">Accountant</a>
            <a href="logout.php">Logout</a>
          </div>
      </div>
      <!--1st header end-->

      <!--Home page menue start-->
      <div class="menue">
        <a href="#">Payment</a>
        <a href="blood.php">Bloodbank</a>
        <a href="medicine/medicine.php">Medicine</a>
        <a href="doctor/operationlist.php">Operation's</a>
        <a href="birthreport.php">Birth Report</a>
        <a href="deathreport.php">Death Report</a>
        <a href="#">Bed Allotment </a>
      </div>
      <!--Home page menue End-->
      <!--Analog Clock-->
      <div id="sabuj">
      <h1>Courrent Time</h1>
      <div id="a1"></div>
      </div>
      <!--Calander-->
      <div class="calander">
        <div id="calendar"></div>
	    </div>

<!-- Add Blood html from-->
<div class="non-semantic-protector">
        	<h1 class="ribbon">
        		<strong class="ribbon-content">Add New Blood</strong>
        	</h1>
  </div>
  <div class="main">
    <form class="form_div" action="#" method="post">
      <span>Donor's Name:</span><input type="text" name="name" >
      <span>Donation Date</span><input type="date" name="ddate">
      <span>Donation Time</span><input type="time" name="dtime">
      <span>Age</span><input type="number" name="age" >
      <span>BLoog Group</span>
      <select class="sex" name="bg">
          <option>Select</option>
          <option>A(+ve)</option>
          <option>A(-ve)</option>
          <option>B(+ve)</option>
          <option>B(-ve)</option>
          <option>AB(+ve)</option>
          <option>AB(-ve)</option>
          <option>O(+ve)</option>
          <option>O(-ve)</option>
      </select>
      <span>Amount (pack)</span><input type="number" name="bag_num" value="">
      <input type="submit" name="submit" value="Add">
    </form>
  </div>
<!--Fooer Area-->
<div class="footer">
 <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="http://sabuj.bdonlinesolution.com">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
</div>
  </body>
</html>
