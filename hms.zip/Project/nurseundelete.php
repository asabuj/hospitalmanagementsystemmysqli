<?php require('session.php'); ?>
<?php
//PROGRAM : To make data delete (invisible) from user but not from MySQL Database
//CODED BY : Sabuj Chandra Roy
//DATABASE NAME : project
//Table Name : Nurse
//DATE : 2-Feb 2018
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $visibility = 1;
  $update_query = "UPDATE nurse SET `visible`= '{$visibility}' WHERE `id`='{$id}' ";
  if (mysqli_query($connection,$update_query)) {
    echo "<script>window.location.href = 'nurse.php'</script>";
  }else{
    echo "ERROR : failed to Delete data"."<br>";
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
?>
