<?php require('session.php'); ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Birth Report</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/rabon.css">
    <link rel="stylesheet" href="css/stylephp.css">
    <script src="js/clock.js" charset="utf-8"></script>
    <script src="js/calander.js" charset="utf-8"></script>
</head>
  <body onload="displayCalendar(),startTime()">
    <!--Hospital Name start-->
    <div class="name">
      <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
      <div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
      <h2>Hospital Management System</h2>
    </div>
    <!--Hospital Name End-->
    <!--1st header-->
    <div class="header">
        <div class="admin">
          <marquee behavior="alternate" scrollamount="2s"><h4><?php
          include('dbconnect.php');
            if (!mysqli_connect_errno()) {
              $query = "SELECT * FROM user WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);

              if($result){
                echo "Current User:-".$row['username'];
              }
            }?></h4></marquee>
        </div>
        <div class="logout">
          <a href="home.php">Home</a>
          <a href="doctor.php">Doctor's</a>
          <a href="nurse.php">Nurse</a>
          <a href="patient.php">Patient's</a>
          <a href="pharmacist.php">Pharamacist</a>
          <a href="labrotorist.php">Laboratist</a>
          <a href="accounts.php">Account's</a>
          <a href="profile.php">Profile</a>
          <a href="logout.php">Logout</a>
        </div>
    </div>
    <!--1st header end-->

    <!--Home page menue start-->
    <div class="menue">
      <a href="appoitmentlist.php">Appoinment</a>
      <a href="blood.php">Bloodbank</a>
      <a href="medicine.php">Medicine</a>
      <a href="operationlist.php">Operation's</a>
      <a class= "active" href="birthreport.php">Birth Report</a>
      <a href="deathreport.php">Death Report</a>
      <a href="beddetails.php">Bed Status </a>
    </div>
    <!--Home page menue End-->
    <!--Analog Clock-->
    <div id="sabuj">
    <h1>Current Time</h1>
    <div id="a1"></div>
    </div>
      <!--Calander-->
      <div id="calendar"></div>
<!-- Admit Patient-->
<div class="submenu">
  <a href="adbirthreport.php">Add New Birth Report</a>
</div>
<div class="non-semantic-protector">
        	<h1 class="ribbon">
        		<strong class="ribbon-content">Birth Report</strong>
        	</h1>
</div>
<div style="min-height: 330px;">
<?php
include('dbconnect.php');
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM birth_r WHERE `visible` = 1";
    $result = mysqli_query($connection, $query);

    if($result){
      echo "<table id='tbl'>
    <tr>
      <th>Sl. No.</th>
      <th>Child Name</th>
      <th>Date of Birth</th>
      <th>Time of Birth</th>
      <th>Weight</th>
      <th>Birth Place</th>
      <th>Father Name</th>
      <th>Mother Name</th>
      <th>BLood Group</th>
      <th>Gender</th>
      <th>Religion</th>
      <th>View Report</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td style='text-align:left;'>".ucwords($row['name'])."</td>";
      echo "<td>".$row['dob']."</td>";
      echo "<td>".$row['tdob']."</td>";
      echo "<td>".$row['weight']."</td>";
      echo "<td>".$row['place']."</td>";
      echo "<td style='text-align:left;'>".ucwords($row['f_name'])."</td>";
      echo "<td style='text-align:left;'>".ucwords($row['m_name'])."</td>";
      echo "<td>".$row['bg']."</td>";
      echo "<td>".$row['sex']."</td>";
      echo "<td>".$row['religion']."</td>";
      echo "<td>"."<a href = 'birthc.php?id=$id' id='delete'>View</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
 ?>
</div>

<div class="footer">
 <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
</div>

  </body>
</html>
