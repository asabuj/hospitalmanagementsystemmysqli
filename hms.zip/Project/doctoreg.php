<?php require('session.php'); ?>
<?php
//PROGRAM : CRUD operation on hospital management project
//CODED BY : Sabuj Chandra Roy
//DATE : 2-Feb-2018
//DATABASE NAME : project
//Table Name : newdoctor
//WRITE INTO THE DATABASE
include('dbconnect.php');
if (isset($_POST['submit'])){
  $dname = $_POST['name'];
  $specility = $_POST['special'];
  $email =$_POST['mail'];
  $uname = $_POST['uname'];
  $psw = $_POST['psw'];
  if(!mysqli_connect_errno()){
    $query = "INSERT INTO `doclog` (`name`, `special`, `mail`, `username`, `password`, `visible`) VALUES('{$dname}', '{$specility}', '{$email}', '{$uname}', '{$psw}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Registion successfully ');</script></b>";
      echo "<script>window.location.href = 'index.php'</script>";
    }else{
      echo "<b><script>alert('SUCCESS : Registion Unsuccessful, Your user name or mail already exist');</script></b>";
      echo "<script>window.location.href = 'doctorreg.php'</script>";
    }
  }else{
    die("ERROR : ".mysqli_connect_errno());
  }
  mysqli_close($connection);
}

 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Doctor Registion From</title>
  </head>
  <body>
    <center><h2>Registion From</h2></center>
    <center><form class="" action="#" method="post">
      <span>Full Name: </span><input type="text" name="name"><br><br>
      <span>Speciality: </span>
      <select class="sex" name="special">
          <option>Specilization</option>
          <option>Neurologist</option>
          <option>Cardiology</option>
          <option>Colorectal Surgery</option>
          <option>Gynaecology </option>
          <option>Obstetrics</option>
          <option>Spinal Surgery</option>
          <option>Ophthalmology</option>
          <option>Paediatrics</option>
          <option>Gastroenterology</option>
          <option>Endocrinology</option>
          <option>Dermatology</option>
          <option>Urology</option>
          <option>Medicine</option>
          <option>Nephrology</option>
          <option>Psychiatry</option>
      </select><br><br>
      <span>Email Address:</span><input type="email" name="mail" required><br><br>
      <span>Choose User Name: </span><input type="text" name="uname"><br><br>
      <span>Password:</span><input type="password" name="psw" value=""><br><br>
      <input type="submit" name="submit" value="Registion">
    </form></center>
  </body>
</html>
