<?php require('session.php'); ?>
<!DOCTYPE html>
<html>
<!--
//Programar: Sabuj Chandra roy
//Hospital Management System Project
//Database name Project;
//Uses All different table
//Create Start date: 02-01-2018
//Last Update: 07-03-2018
-->
  <head>
    <meta charset="utf-8">
    <title>Doctor List</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/stylephp.css">
    <link rel="stylesheet" href="css/rabon.css">
    <script src="js/clock.js" charset="utf-8"></script>
    <script src="js/calander.js" charset="utf-8"></script>
  </head>
  <body onload="displayCalendar(),startTime()">
    <!--Hospital Name start-->
    <div class="name">
      <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
      <div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
      <h2>Hospital Management System</h2>
    </div>
    <!--Hospital Name End-->
    <!--1st header-->
    <div class="header">
        <div class="admin">
          <marquee behavior="alternate" scrollamount="2s"><h4><?php
          include('dbconnect.php');
            if (!mysqli_connect_errno()) {
              $query = "SELECT * FROM user WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);

              if($result){
                echo "Current User:-".$row['username'];
              }
            }?></h4></marquee>
        </div>
        <div class="logout">
          <a href="home.php">Home</a>
          <a class= "active" href="doctor.php">Doctor's</a>
          <a href="nurse.php">Nurse</a>
          <a href="patient.php">Patient's</a>
          <a href="pharmacist.php">Pharamacist</a>
          <a href="labrotorist.php">Laboratist</a>
          <a href="accounts.php">Account's</a>
          <a href="profile.php">Profile</a>
          <a href="logout.php">Logout</a>
        </div>
    </div>
    <!--1st header end-->

    <!--Home page menue start-->
    <div class="menue">
      <a href="appoitmentlist.php">Appoinment</a>
      <a href="blood.php">Bloodbank</a>
      <a href="medicine.php">Medicine</a>
      <a href="operationlist.php">Operation's</a>
      <a href="birthreport.php">Birth Report</a>
      <a href="deathreport.php">Death Report</a>
      <a href="beddetails.php">Bed Status </a>
    </div>
    <!--Home page menue End-->
    <!--Analog Clock-->
    <div id="sabuj">
    <h1>Current Time</h1>
    <div id="a1"></div>
    </div>
      <!--Calander-->
      <div class="calander">

	<div id="calendar"></div>
</div>
  <!-- Doctor List-->

  <div id="navbar">
    <div class="submenu">
      <a href="adddoctor.php">Add Newdoctor</a>
    </div>
        <div class="non-semantic-protector">
        	<h1 class="ribbon">
        		<strong class="ribbon-content">Doctor List</strong>
        	</h1>
        </div>
  </div>
  <div=class="">
  <form method="post" action="doctor.php" style="margin-top: -30px;padding: 4px;">
    <input  type="text" name="q" placeholder="Check Validity..." style="border:1px solid lightgray; border-radius: 6px;">
    <select name="column" style="border:1px solid lightgray; border-radius: 6px;height:30px;">
      <option value="">--Select--</option>
      <option value="dname">Name</option>
      <option value="mail">Email</option>
      <option value="mobile">Mobile Number</option>
    </select>
    <input type="submit" name="submit" value="Check" style="border-radius:3px;width:80px;border:1px solid lightgray;margin-left:0px; font-weight:bold;" >
  </form>
</div>

<div class="searchphp">
  <!--Search Area PHP in mysqli -->
  <?php
  include('dbconnect.php');
   if (isset($_POST['submit'])) {
     $sabuj = $connection->real_escape_string($_POST['q']);
     $column = $connection->real_escape_string($_POST['column']);
     if ($column == "" || ($column != "dname" && $column != "mail" && $column != "mobile"))
       $column = "dname" && "mail" && "mobile";
     $sql = $connection->query("SELECT * FROM newdoctor WHERE $column LIKE '%$sabuj%' AND visible=1");
     if ($sql->num_rows > 0) {
       while ($data = $sql->fetch_array())
       {
         $id =  $data['id'];
         echo "Name-"."<b>".$data['dname']."</b>".", "."Email Address-"."<b>". $data['mail']."</b>".", "."Mobile No-"."<b>". $data['mobile']."</b>"."<a href = 'delete.php?id=$id' style='text-decoration: none;margin-left: 2%;border: 1px solid lightblue;padding: 2px 20px;border-radius: 3px;'>Delete</a>"."<a href = 'update.php?id=$id' style='text-decoration: none;margin-left: 2%;border: 1px solid lightblue;padding: 2px 20px;border-radius: 3px;'>Update</a>"."<br>";
       }
     } else
       echo "<b>"."Data Not Valid, Check Again"."</b>";
   }
  ?>
  <br>
  <div style="min-height: 300px;">
  <?php
  include('dbconnect.php');
  include('function.php');
    if (!mysqli_connect_errno()) {
      $query = "SELECT * FROM newdoctor WHERE `visible` = 1";
      $result = mysqli_query($connection, $query);

      if($result){
        echo "<table id='tbl'>
      <tr>
        <th>Sl. No.</th>
        <th style='width:200px;'>Name</th>
        <th>Qualification</th>
        <th>Specialization</th>
        <th>Monthly Salary</th>
        <th>Mobile</th>
        <th>Address</th>
        <th>Age</th>
        <th>Join Date</th>
        <th>Update</th>
        <th>Remove</th>
      </tr>";
      $sl_no = 0;
      while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
        $sl_no = $sl_no + 1;
        $id = $row['id'];
        echo "<tr>";
        echo "<td>".$sl_no."</td>";
        echo "<td style='text-align:left;'>".ucwords($row['dname'])."</td>";
        echo "<td>".$row['ql']."</td>";
        echo "<td>".$row['sp']."</td>";
        echo "<td>".$row['salary']."</td>";
        echo "<td>".$row['mobile']."</td>";
        echo "<td>".$row['address']."</td>";
        echo "<td>".$row['age']."</td>";
        echo "<td>".$row['jdate']."</td>";
        echo "<td>"."<a href = 'update.php?id=$id' id='update'>Edit</a>"."</td>";
        echo "<td>"."<a href = 'delete.php?id=$id' id='delete'>Del</a>"."</td>";
        echo "</tr>";
    }
    echo "</table>";
      }
    }else{
      die("ERROR : ".mysqli_connect_error());
    }
    mysqli_close($connection);
   ?>
</div>
        <div class="footer">
        <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
      </div>

</body>
</html>
