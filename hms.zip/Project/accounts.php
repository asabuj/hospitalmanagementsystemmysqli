<?php
require('session.php');
 ?>
<!DOCTYPE html>
<html>
<!--
//Programar: Sabuj Chandra roy
//Hospital Management System Project
//Database name Project;
//Uses All different table
//Create Start date: 02-01-2018
//Last Update: 07-03-2018
-->
  <head>
    <meta charset="utf-8">
    <title>Accounts</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/stylephp.css">
    <script src="js/clock.js" charset="utf-8"></script>
    <script src="js/calander.js" charset="utf-8"></script>
</head>
  <body onload="displayCalendar(),startTime()" >
    <!--Hospital Name start-->
    <div class="name">
       <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
        <div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
      <div><h2>Hospital Management System</h2></div>
    </div>
    <!--Hospital Name End-->
    <!--1st header-->
      <div class="header">
          <div class="admin">
            <marquee behavior="alternate" scrollamount="2s"><h4><?php
            include('dbconnect.php');
              if (!mysqli_connect_errno()) {
                $query = "SELECT * FROM user WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);

                if($result){
                  echo "Current User:-".$row['username'];
                }
              }?></h4></marquee>
          </div>
          <div class="logout">
            <a href="home.php">Home</a>
            <a href="doctor.php">Doctor's</a>
            <a href="nurse.php">Nurse</a>
            <a href="patient.php">Patient's</a>
            <a href="pharmacist.php">Pharamacist</a>
            <a href="labrotorist.php">Laboratist</a>
            <a  class= "active" href="accounts.php">Account's</a>
            <a href="profile.php">Profile</a>
            <a href="logout.php">Logout</a>
          </div>
      </div>
      <!--1st header end-->

      <!--Home page menue start-->
      <div class="menue">
        <a href="appoitmentlist.php">Appoinment</a>
        <a href="blood.php">Bloodbank</a>
        <a href="medicine.php">Medicine</a>
        <a href="operationlist.php">Operation's</a>
        <a href="birthreport.php">Birth Report</a>
        <a href="deathreport.php">Death Report</a>
        <a href="beddetails.php">Bed Status </a>
      </div>
      <!--Home page menue End-->
      <!--Analog Clock-->
      <div id="sabuj">
      <h1>Current Time</h1>
      <div id="a1"></div>
      </div>
      <!--Calander-->
      <div class="calander">
      	<div id="calendar"></div>
      </div>
<div class="wellcome" style="border:none;">
  <form action="" method="POST" style="float:left;">
    <input type="submit" name="submit1" value="Running Operation ">
  </form>

  <form class="" action="" method="post">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; View Date based Details:<input type="date" name="ddate" style="width:120px;padding:0px;">&nbsp;&nbsp; to
    <input type="date" name="tdate" style="width:120px;padding:0px;">
    <input type="submit" name="done" value="Submit">
  </form>
</div><br>
<div style="min-height: 340px;">
  <?php
  require('dbconnect.php');
  if (isset($_POST['submit1'])) {
    if (!mysqli_connect_errno()) {
      $query = "SELECT * FROM opera WHERE `visible` = 1";
      $result = mysqli_query($connection, $query);
      if($result){
        echo "<table id='tbl' border=2>
      <tr>
        <th>Sl. No.</th>
        <th>Name</th>
        <th>Operation Name</th>
        <th>Fee</th>
        <th>Operation Date</th>
      </tr>";
      $sl_no = 0;
      while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
        $sl_no = $sl_no + 1;
        $id = $row['id'];
        echo "<tr>";
        echo "<td>".$sl_no."</td>";
        echo "<td>".ucwords($row['name'])."</td>";
        echo "<td>".$row['oname']."</td>";
        echo "<td>".$row['fee']."</td>";
        echo "<td>".$row['odate']."</td>";
        echo "</tr>";
    }
    echo "</table>";
      }
    }else{
      die("ERROR : ".mysqli_connect_error());
    }
    mysqli_close($connection);
  }

  /*Date search*/
  include('dbconnect.php');
  if (isset($_POST['done'])) {
  $fdate = $_POST['ddate'];
  $tdate = $_POST['tdate'];
  $connection_read = mysqli_connect($ip, $user, $password, $dbname);
    if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM opera WHERE `odate` BETWEEN '$fdate' AND  '$tdate'";
    $result = mysqli_query($connection,$query);
    if($result){
      echo "<table id='tbl'>
      <tr>
        <td>sl no</td>
         <td>Id</td>
         <td>Name</td>
         <td>Date</td>
         <td>fees</td>
      </tr>";
    $sl_no=0;
    $qty1= 0;
    while ($row = mysqli_fetch_array ($result, MYSQLI_BOTH)) {
      $qty1 += $row['fee'];
      $sl_no = $sl_no+1;
      echo "<tr>";
      echo "<td>". "$sl_no"."</td>" ;
      echo "<td>".$row['sid']."</td>";
      echo "<td>".$row['name']."</td>";
      echo "<td>".$row['odate']."</td>";
      echo "<td>".$row['fee']."</td>";
      echo "</tr>";
    } echo "Your input Date"." &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"."<b>". $fdate."</b>". "&nbsp;&nbsp;&nbsp; ". "to". "&nbsp;&nbsp;&nbsp;". "<b>". $tdate."</b>"."<br>"."Total Fee of Operation". " = ". "<b>". $qty1. "৳". "</b>";
      // echo "<tr>";
      // echo "<td>"."</td>" ;
      // echo "<td>"."</td>" ;
      // echo "<td>". "</td>" ;
      // echo "<td>". "</td>" ;
      // echo "<td>"."Total" . "= ". $qty1 ."</td>" ;
      // echo "</tr>";

    echo "</table>";
     }else{
    echo "Database Connection Failed";
    }
    mysqli_close($connection);
  }}
  ?>
  </div>
  <div class="footer">
   <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
  </div>



  </body>
</html>
