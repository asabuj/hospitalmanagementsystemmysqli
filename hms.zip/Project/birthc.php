<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `name`, `dob`,`tdob`,`weight`, `place`, `f_name`, `m_name`, `bg`, `sex`, `religion`, `ref` FROM birth_r WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $name =$row['name'];
    $dob=$row['dob'];
    $tdob=$row['tdob'];
    $weight=$row['weight'];
    $place=$row['place'];
    $fname=$row['f_name'];
    $mname=$row['m_name'];
    $bg=$row['bg'];
    $gender=$row['sex'];
    $religion=$row['religion'];
    $ref = $row['ref'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Print Birth Certificate</title>
    <link rel="stylesheet" href="css/birth.css">
    <script type="text/javascript">
    function printDiv(main) {
  var printContents = document.getElementById(main).innerHTML;
  var originalContents = document.body.innerHTML;

  document.body.innerHTML = printContents;

  window.print();

  document.body.innerHTML = originalContents;
}
    </script>
  </head>
  <body>
    <div class="back" style="margin-left:15%; border:1px solid dodgerblue; width:40px; text-align:center; background-color:lightgray;"><a href="birthreport.php"style="text-decoration:none;font-weight:bold;">Back</a></div>
    <div id="printableArea" class="main">
      <input type="button" onclick="printDiv('printableArea')" value="print" />

      <div class="header">
        <div class="logo">
          <img src="imge/dhaka.png" alt="">
        </div>
        <div class="hname">
      <h2>Dhaka Medical College & Hospital</h2>
        <h4>Dhaka, </h4>
        <p> Phone : 02-55165088<br>Web: www.dmc.gov.bd</p>
    </div>
<div class="ref">
  <p>Ref: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $ref;?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date: ..................</p>
</div>
  </div>
  <div class="details">
    <h3>Details of Child</h3>
    <p>Child Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b><i><?php echo $name;?></i></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sex:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b><i><?php echo $gender;?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i></b>BLood Group:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><i><?php echo $bg;?></i></b><br>Date of Birth:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><i><?php echo $dob;?></i></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Time of Birth:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><i><?php echo $tdob;?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i></b>Birth Weight:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><i><?php echo $weight;?></i></b><br>Father Name: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><i><?php echo $fname;?></i></b><br>Mothers Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><i><?php echo $mname;?></i></b><br> Religion:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><i><?php echo $religion;?></i></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Address:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><i><?php echo $place;?></i></b></p>
  </div>
  <div class="place">
    <p>Place of Birth With Full address: Dhaka Medical College & Hospital,
Dhaka, Bangladesh. Phone:02-55165088.</p>
  </div>
  <div class="office">
    <p>Consultant’s Name:............................ Seal & Date:</p><b>Singture.........</b>
  </div>
</div>
  </body>
</html>
