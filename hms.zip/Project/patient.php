<?php require('session.php'); ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Patient List</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/rabon.css">
    <link rel="stylesheet" href="css/stylephp.css">
    <script src="js/clock.js" charset="utf-8"></script>
    <script src="js/calander.js" charset="utf-8"></script>
    <script>
        function check_delete()
        {
            var chk = confirm('Are You Want To Delete This');
            if (chk)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    </script>
  </head>
  <body onload="displayCalendar(),startTime()">
    <!--Hospital Name start-->
    <div class="name">
      <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
      <div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
      <h2>Hospital Management System</h2>
    </div>
    <!--Hospital Name End-->
    <!--1st header-->
    <div class="header">
        <div class="admin">
          <marquee behavior="alternate" scrollamount="2s"><h4><?php
          include('dbconnect.php');
            if (!mysqli_connect_errno()) {
              $query = "SELECT * FROM user WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);

              if($result){
                echo "Current User:-".$row['username'];
              }
            }?></h4></marquee>
        </div>
        <div class="logout">
          <a href="home.php">Home</a>
          <a href="doctor.php">Doctor's</a>
          <a href="nurse.php">Nurse</a>
          <a class= "active" href="patient.php">Patient's</a>
          <a href="pharmacist.php">Pharamacist</a>
          <a href="labrotorist.php">Laboratist</a>
          <a href="accounts.php">Account's</a>
          <a href="profile.php">Profile</a>
          <a href="logout.php">Logout</a>
        </div>
    </div>
    <!--1st header end-->

    <!--Home page menue start-->
    <div class="menue">
      <a href="appoitmentlist.php">Appoinment</a>
      <a href="medicine.php">Medicine</a>
      <a href="operationlist.php">Operation's</a>
      <a href="blood.php">Bloodbank</a>
      <a href="birthreport.php">Birth Report</a>
      <a href="deathreport.php">Death Report</a>
      <a href="beddetails.php">Bed Status </a>
    </div>
    <!--Home page menue End-->
    <!--Analog Clock-->
    <div id="sabuj">
    <h1>Current Time</h1>
    <div id="a1"></div>
    </div>
      <!--Calander-->
        <div id="calendar"></div>
<!--Patient list-->
<div class="submenu">
  <a href="admitpatient.php">Add New Patient</a>
</div>
   <div class="non-semantic-protector">
        	<h1 class="ribbon">
        		<strong class="ribbon-content">Patient List</strong>
        	</h1>
        </div>
        <!-- Search From-->
        <form method="post" action="patient.php" style="margin-top: -30px;padding: 4px;">
          <input  type="text" name="sabuj" placeholder="Check Validity..." style="border:1px solid lightgray; border-radius: 6px;">
          <select name="column" style="border:1px solid lightgray; border-radius: 6px;height:30px;">
            <option value="">--Select--</option>
            <option value="name">Name</option>
            <option value="problem">Problem</option>
            <option value="mobile">Mobile Number</option>
          </select>
          <input type="submit" name="submit" value="Check" style="border-radius:3px;width:80px;border:1px solid lightgray;margin-left:0px; font-weight:bold;" >
        </form>

        <?php
        include('dbconnect.php');
         if (isset($_POST['submit'])) {
           $sabuj = $connection->real_escape_string($_POST['sabuj']);
           $column = $connection->real_escape_string($_POST['column']);
           if ($column == "" || ($column != "name" && $column != "problem" && $column != "mobile"))
             $column = "name" && "problem" && "mobile";
           $sql = $connection->query("SELECT * FROM adpatient WHERE $column LIKE '%$sabuj%'");
           if ($sql->num_rows > 0) {
             while ($data = $sql->fetch_array()){
               $id=$data['id'];
              echo "Name-"."<b>".$data['name']."</b>".", "."Problem-"."<b>". $data['problem']."</b>".", "."Mobile No-"."<b>". $data['mobile']."</b>"."<a href = 'updatepatinet.php?id=$id' style='text-decoration: none;margin-left: 2%;border: 1px solid lightblue;padding: 2px 20px;border-radius: 3px;'>Edit</a>"."<a href = 'deletepatient.php?id=$id' onclick='return check_delete()' style='text-decoration: none;margin-left: 2%;border: 1px solid lightblue;padding: 2px 20px;border-radius: 3px;'>Release</a>"."<br>";}
           } else
             echo "<b>"."Data Not Valid, Check Again"."</b>";
         }
        ?>
        <br>
  <!--read data-->
  <div style="min-height: 300px;">
  <?php
  include('dbconnect.php');
    if (!mysqli_connect_errno()) {
      $query = "SELECT * FROM adpatient WHERE `visible` = 1";
      $result = mysqli_query($connection, $query);
      if($result){
        echo "<table id='tbl'>
      <tr>
        <th>Sl. No.</th>
        <th style='width:200px;'>Patient Name</th>
        <th>Problem</th>
        <th>Gender</th>
        <th>Age</th>
        <th>Blood Group</th>
        <th>Patient Address</th>
        <th>Mobile No</th>
        <th>Admission Date</th>
        <th>Update</th>
        <th>Release</th>
      </tr>";
      $sl_no = 0;
      while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
        $sl_no = $sl_no + 1;
        $id = $row['id'];
        echo "<tr>";
        echo "<td>".$sl_no."</td>";
        echo "<td style='text-align:left;'>".ucwords($row['name'])."</td>";
        echo "<td>".$row['problem']."</td>";
        echo "<td>".$row['gender']."</td>";
        echo "<td>".$row['age']."</td>";
        echo "<td>".$row['bloodgroup']."</td>";
        echo "<td>".$row['address']."</td>";
        echo "<td>".$row['mobile']."</td>";
        echo "<td>".$row['jdate']."</td>";
        echo "<td>"."<a href = 'updatepatient.php?id=$id' id='update'>Edit</a>"."</td>";
        echo "<td>"."<a href = 'deletepatient.php?id=$id' onclick='return check_delete()' id='delete'>Release</a>"."</td>";
        echo "</tr>";
    }
    echo "</table>";
      }
    }else{
      die("ERROR : ".mysqli_connect_error());
    }
    mysqli_close($connection);
   ?>
 </div>
      <div class="footer">
        <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
      </div>
  </body>
</html>
