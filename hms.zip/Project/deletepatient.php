<?php require('session.php'); ?>
<?php
//PROGRAM : To make data delete (invisible) from user but not from MySQL Database
//CODED BY : Sabuj Chandra Roy
//DATABASE NAME : project
//Table Name : doctor
//DATE : 2-Feb 2018
require 'dbconnect.php';
$id = $_GET['id'];
$sql = "DELETE FROM adpatient WHERE id='$id'";
mysqli_query($connection, $sql);
header("Location: patient.php");
?>
