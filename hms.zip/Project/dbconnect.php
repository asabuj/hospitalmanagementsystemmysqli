<?php
//Programar: Sabuj Chandra roy
//Hospital Management System Project
//Database name Project;
//Uses All different table
//Create Start date: 02-01-2018
//Last Update: 07-03-2018
$ip = 'localhost';
$user = 'root';
$password = '';
$dbname = 'project';
$visibility = 1;
$connection = mysqli_connect($ip, $user, $password, $dbname);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
 ?>
