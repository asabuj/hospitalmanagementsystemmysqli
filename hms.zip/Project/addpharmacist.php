<?php require('session.php'); ?>
<?php
include('dbconnect.php');
if (isset($_POST['submit'])){
  $name = $_POST['name'];
  $depertment = $_POST['dep'];
  $dtime = $_POST['dtime'];
  $dday = $_POST['dday'];
  $salary = $_POST['salary'];
  $mobile = $_POST['mobile'];
  if(!mysqli_connect_errno()){
    $visibility = 1;
    $query = "INSERT INTO `pharmacist` (`name`, `department`, `dtime`, `dday`, `salary`, `mobile`, `visible`) VALUES('{$name}', '{$depertment}', '{$dtime}', '{$dday}','{$salary}', '{$mobile}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Pharmacist Added successfully');</script></b>";
      echo "<script>window.location.href = 'pharmacist.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_errno());
  }
  mysqli_close($connection);
}
?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Add Pharmacist</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/clock.css">
    <link rel="stylesheet" href="css/rabon.css">
    <link rel="stylesheet" href="css/stylephp.css">
    <script src="js/clock.js" charset="utf-8"></script>
    <script src="js/calander.js" charset="utf-8"></script>
</head>
  <body onload="displayCalendar(),startTime()">
    <!--Hospital Name start-->
    <div class="name">
      <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
      <div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
      <h2>Hospital Management System</h2>
    </div>
    <!--Hospital Name End-->
    <!--1st header-->
    <div class="header">
        <div class="admin">
          <marquee behavior="alternate" scrollamount="2s"><h4><?php
          include('dbconnect.php');
            if (!mysqli_connect_errno()) {
              $query = "SELECT * FROM user WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);

              if($result){
                echo "Current User:-".$row['username'];
              }
            }?></h4></marquee>
        </div>
        <div class="logout">
          <a href="home.php">Home</a>
          <a href="doctor.php">Doctor's</a>
          <a href="nurse.php">Nurse</a>
          <a href="patient.php">Patient's</a>
          <a  class= "active" href="pharmacist.php">Pharamacist</a>
          <a href="labrotorist.php">Laboratist</a>
          <a href="accounts.php">Account's</a>
          <a href="profile.php">Profile</a>
          <a href="logout.php">Logout</a>
        </div>
    </div>
    <!--1st header end-->

    <!--Home page menue start-->
    <div class="menue">
      <a href="appoitmentlist.php">Appoinment</a>
      <a href="blood.php">Bloodbank</a>
      <a href="medicine.php">Medicine</a>
      <a href="operationlist.php">Operation's</a>
      <a href="birthreport.php">Birth Report</a>
      <a href="deathreport.php">Death Report</a>
      <a href="beddetails.php">Bed Status </a>
    </div>
    <!--Home page menue End-->
    <!--Analog Clock-->
    <div id="sabuj">
    <h1>Current Time</h1>
    <div id="a1"></div>
    </div>
      <!--Calander-->
      <div class="calander">
        <div id="calendar"></div>
      </div>
<!-- Add Pharmacist-->
<div class="submenu">
  <a href="pharmacist.php">Back Pharmacist List</a>
</div>
<div class="non-semantic-protector">
        	<h1 class="ribbon">
        		<strong class="ribbon-content">Add New Phamacist</strong>
        	</h1>
  </div>
  <!--own immage-->
  <div class="dev" style="float:left; margin-left:5%">
  <h4 style="text-align:center;">Developer</h4>
       <img src="imge/sabuj.png" alt="" width:"200px" height="150px" style="border:1px solid lightgray; border-radius:50%;">
       <p><strong>Sabuj Chandra roy</strong><br>Beginer Web Developer</p>
     </div>
     <div class="dev" style="float:right; margin-right:5%">
       <h4 style="text-align:center;">My Honorable Trainer</h4>
       <img src="imge/suman.jpg" alt="" width:"200px" height="150px" style="border:1px solid lightgray; border-radius:50%;margin-left:20%;">
       <p><strong>Suman Gangopadhyay</strong><br>Trainer-Web Development,<strong>IIHT</strong></p>
     </div>
     <!--End imgage style-->
  <div class="main">
    <form class="form_div" action="#" method="post">
      <span>Pharmacist Name : </span>
      <input type="text" name="name" placeholder="Name" required>
      <span>Department</span>
      <select class="sex" name="dep">
          <option>Department</option>
          <option>ICU</option>
          <option>Emergency</option>
          <option>Diagnostic</option>
          <option>Radiotherapy</option>
          <option>Physiotherapy</option>
          <option>Ophthalmology</option>
          <option>Neurology</option>
          <option>Maternity </option>
      </select>
      <span>Duity Time:</span>
      <select class="sex" name="dtime">
          <option>Duity Time</option>
          <option>6AM to 2Pm</option>
          <option>2PM to 10PM</option>
          <option>10PM to 6AM</option>
      </select>
      <span>Duity Day:</span>
      <select class="sex" name="dday">
          <option>Duity Day</option>
          <option>Every Day</option>
          <option>Sun, Tue, Wed, Fri</option>
          <option>Sat, Mon, Thu</option>
      </select>
      <span>Monthly Salary:</span>
      <input type="number" name="salary" placeholder="Monthly Salary" required>
      <span>Mobile Number: </span>
      <input type="number" name="mobile" placeholder="mobile" required>
      <input type="reset" name="reset" value="Clear">
      <input type="submit" name="submit" value="Add">
    </form>
  </div>
<!--Footer Area-->
<div class="footer">
 <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="http://sabuj.bdonlinesolution.com">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
</div>-->
  </body>
</html>
