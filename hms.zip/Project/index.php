<?php
session_start();
include('dbconnect.php');
//admin login
if(isset($_POST['submit'])) {
  $visibility = 1;
  $myusername = mysqli_real_escape_string($connection,$_POST['username']);
  $mypassword = mysqli_real_escape_string($connection,$_POST['password']);
  $sql = "SELECT `id` FROM user WHERE `username`= '{$myusername}' and `password` = '{$mypassword}' AND `visible` = '{$visibility}'";
  $result = mysqli_query($connection,$sql);
  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
  $active = $row['active'];
  $count = mysqli_num_rows($result);
  // If result matched $myusername and $mypassword, table row must be 1 row
  if($count == 1) {
    $_SESSION['user'] = $myusername;
    header("location: home.php");
  }else {
    echo "<script>alert('Your Login Name or Password is invalid');</script>";
  }
}

//doctor login
if(isset($_POST['login'])) {
  $visibility = 1;
  $myusername = mysqli_real_escape_string($connection,$_POST['dusername']);
  $mypassword = mysqli_real_escape_string($connection,$_POST['dpassword']);
  $sql = "SELECT `id` FROM doclog WHERE `username`= '{$myusername}' and `password` = '{$mypassword}' AND `visible` = '{$visibility}'";
  $result = mysqli_query($connection,$sql);
  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
  $active = $row['active'];
  $count = mysqli_num_rows($result);
  // If result matched $myusername and $mypassword, table row must be 1 row
  if($count == 1) {
    $_SESSION['doclog'] = $myusername;
    header("location: doctor/dhome.php");
  }else {
    echo "<script>alert('Your Login Name or Password is invalid');</script>";
  }
}
?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" type="text/css" href="css/slide.css" />
    <script type="text/javascript" src="js/modernizr.custom.86080.js"></script>
  </head>
  <body>
    <!--Background Slide Show-->
    <div>
    <ul class="cb-slideshow">
        <li><span>Image 01</span><div><h4>সরকারের সহায়তায় আইসিটিতে এগিয়ে যাচ্ছে নারী</h4></div></li>
        <li><span>Image 02</span><div><h4>Paypal+Zoom Lunching Program 2017</h4></div></li>
        <li><span>Image 03</span><div><h4>ক্রিকেটার শাকিবকে দেখতে প্রধানমন্ত্রী এপোলো হাসপাতালে</h4></div></li>
        <li><span>Image 04</span><div><h4>বন্যার্তদের সহায়তায় প্রধানমন্ত্রী কুড়িগ্রামে</h4></div></li>
        <li><span>Image 05</span><div><h4>গোলাম মস্তোফাকে দেখতে প্রধানমন্ত্রী হাসপাতালে</h4></div></li>
        <li><span>Image 06</span><div><h4>৫ কোটি টাকার বদলে এম্বুলেন্স নিলেন ক্রিকেটার মুশফিক</h4></div></li>
    </ul>
    </div>
    <!--End of Background Slid Show-->
    <div class="container">
    <div class="main">
      <div class="adminlogin">
          <form action="#" method="post">
            <h3>Admin login</h3>
            <span class="fontawesome-user"></span>
              <input type="text" id="user" name="username" placeholder="Username" autocomplete="off" required>
              <span class="fontawesome-lock"></span>
              <input type="password" id="pass" name="password" placeholder="Password" autocomplete="off" required>
              <a class="link" href="#">Lost your password?</a>
              <input type="submit" name="submit" value="Login">
              <p><strong>username: sabuj<br>password:sabuj</strong></p>
          </form>
      </div>

      <div class="doctorlogin">
          <form action="#" method="post">
            <h3>Staff's login</h3>
            <span class="fontawesome-user"></span>
              <input type="text" id="user" name="dusername" placeholder="Username" autocomplete="off" required>
              <span class="fontawesome-lock"></span>
              <input type="password" id="pass" name="dpassword" placeholder="Password" autocomplete="off" required>
              <a class="link" href="#">Lost your password?</a>
              <input type="submit" name="login" value="Login">
              <a class="link" href="doctorreg.php">Are You New Doctor?</a>
              <p><strong>username: sabuj<br>password:123456</strong></p>
          </form>
      </div>
    </div>
    <div><a href="file/hms(sabuj-G044659).pdf" download  style="font-size:30px;color:red;"><strong>Please download the Submission File</strong></a></div>

      <div class="footer">
        <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
      </div>
    </div>
  </body>
</html>
