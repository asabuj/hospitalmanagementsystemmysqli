<?php
require('session.php');
 ?>
<?php
include('function.php');
include('dbconnect.php');
if (isset($_POST['submit'])){
  $dname = $_POST['name'];
  $equilification = $_POST['quilification'];
  $specility = $_POST['special'];
  $bloodgroup = $_POST['blood'];
  $gender = $_POST['sex'];
  $monthsalary = $_POST['salary'];
  $page = $_POST['age'];
  $contact = $_POST['phone'];
  $email =$_POST['mail'];
  $address =$_POST['address'];
  $birthday =$_POST['bdate'];
  $birthday = mysql_date($birthday);
  $joindate =$_POST['jdate'];
  $joindate =mysql_date($joindate);
  if(!mysqli_connect_errno()){
    $visibility = 1;
    $query = "INSERT INTO `newdoctor` (`dname`, `ql`, `sp`, `bg`, `gn`, `salary`, `age`, `mobile`, `mail`, `address`, `dob`, `jdate`, `visible`) VALUES('{$dname}', '{$equilification}', '{$specility}', '{$bloodgroup}','{$gender}','{$monthsalary}', '{$page}', '{$contact}', '{$email}', '{$address}', '{$birthday}', '{$joindate}', '{$visibility}')";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Doctor Added successfully');</script></b>";
      echo "<script>window.location.href = 'doctor.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_errno());
  }
  mysqli_close($connection);
}
 ?>

 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <title>Add Doctor</title>
     <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="css/rabon.css">
     <link rel="stylesheet" href="css/stylephp.css">
     <link rel="stylesheet" href="css/jquery-ui.css">
     <script src="js/clock.js" charset="utf-8"></script>
     <script src="js/calander.js" charset="utf-8"></script>
     <script src="js/dob.js" charset="utf-8"></script>
    <script src="js/jquery-3.1.0.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script>
      $( function() {
        $( "#dob" ).datepicker({
          changeMonth:true,
          changeYear: true
        });
      });
    </script>
     <script>
     $(document).ready(function(){

     $("#dob").change(function(){
        var value = $("#dob").val();
         var dob = new Date(value);
         var today = new Date();
         var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
         if(isNaN(age)) {

         // will set 0 when value will be NaN
          age=0;

         }
         else{
           age=age;
         }
         $('#age').val(age);

     });

 });
 </script>
 </head>
   <body onload="displayCalendar(),startTime()">
     <!--Hospital Name start-->
     <div class="name">
       <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
       <div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
       <h2>Hospital Management System</h2>
     </div>
     <!--Hospital Name End-->
     <!--1st header-->
     <div class="header">
         <div class="admin">
           <marquee behavior="alternate" scrollamount="2s"><h4><?php
           include('dbconnect.php');
             if (!mysqli_connect_errno()) {
               $query = "SELECT * FROM user WHERE `visible` = 1";
               $result = mysqli_query($connection, $query);

               if($result){
                 echo "Current User:-".$row['username'];
               }
             }?></h4></marquee>
         </div>
         <div class="logout">
           <a href="home.php">Home</a>
           <a class= "active" href="doctor.php">Doctor's</a>
           <a href="nurse.php">Nurse</a>
           <a href="patient.php">Patient's</a>
           <a href="pharmacist.php">Pharamacist</a>
           <a href="labrotorist.php">Laboratist</a>
           <a href="accounts.php">Account's</a>
           <a href="profile.php">Profile</a>
           <a href="logout.php">Logout</a>
         </div>
     </div>
     <!--1st header end-->

     <!--Home page menue start-->
     <div class="menue">
       <a href="appoitmentlist.php">Appoinment</a>
       <a href="blood.php">Bloodbank</a>
       <a href="medicine.php">Medicine</a>
       <a href="operationlist.php">Operation's</a>
       <a href="birthreport.php">Birth Report</a>
       <a href="deathreport.php">Death Report</a>
       <a href="beddetails.php">Bed Status </a>
     </div>
     <!--Home page menue End-->
     <!--Analog Clock-->
     <div id="sabuj">
     <h1>Current Time</h1>
     <div id="a1"></div>
     </div>
       <!--Calander-->
       <div class="calander">

 	<div id="calendar"></div>
 </div>
 <!-- Add Doctor-->
 <div class="submenu">
   <a href="doctor.php">Back Doctor List</a>
 </div>
 <div class="non-semantic-protector">
         	<h1 class="ribbon">
         		<strong class="ribbon-content">Add New Doctor</strong>
         	</h1>
   </div>
<div class="dev" style="float:left; margin-left:5%">
<h4 style="text-align:center;">Developer</h4>
     <img src="imge/sabuj.png" alt="" width:"200px" height="150px" style="border:1px solid lightgray; border-radius:50%;">
     <p><strong>Sabuj Chandra roy</strong><br>Beginer Web Developer</p>
   </div>
   <div class="dev" style="float:right; margin-right:5%">
     <h4 style="text-align:center;">My Honorable Trainer</h4>
     <img src="imge/suman.jpg" alt="" width:"200px" height="150px" style="border:1px solid lightgray; border-radius:50%;margin-left:20%;">
     <p><strong>Suman Gangopadhyay</strong><br>Trainer-Web Development,<strong>IIHT</strong></p>
   </div>
   <div class="main">
     <form class="form_div" action="#" method="post">
       <span>Doctor Name (ডক্টর নাম):</span>
       <input type="text" name="name" placeholder="Doctor name" required>
       <span>Quilification (যোগ্যাতা):</span>
       <select class="sex" name="quilification">
           <option>Quilification</option>
           <option>PGT(SSHMCH)</option>
           <option>MS(Urology)</option>
           <option>FCPS(Medicine)</option>
           <option>MS(Paediatric) </option>
           <option>MD(Child Health)</option>
           <option>DPM</option>
           <option>DCH</option>
           <option>MCPS</option>
           <option>FCPS(Surgery)</option>
           <option>FCPS(Gynae)</option>
           <option>MD(Ped)</option>
           <option>FPT(OGSB)</option>
           <option>CCD(BIRDEM)</option>
           <option>FRSH</option>
           <option>Other</option>
       </select>
       <span>Specilization(স্পেশালিস্ট): </span>
       <select class="sex" name="special">
           <option>Specilization</option>
           <option>Neurologist</option>
           <option>Cardiology</option>
           <option>Colorectal Surgery</option>
           <option>Gynaecology </option>
           <option>Obstetrics</option>
           <option>Spinal Surgery</option>
           <option>Ophthalmology</option>
           <option>Paediatrics</option>
           <option>Gastroenterology</option>
           <option>Endocrinology</option>
           <option>Dermatology</option>
           <option>Urology</option>
           <option>Medicine</option>
           <option>Nephrology</option>
           <option>Psychiatry</option>
       </select>
       <span>BLood Group (রক্তের গ্রুপ): </span>
       <select class="sex" name="blood">
           <option>Blood Group</option>
           <option>A(+ve)</option>
           <option>A(-ve)</option>
           <option>B(+ve)</option>
           <option>B(-ve)</option>
           <option>AB(+ve)</option>
           <option>AB(-ve)</option>
           <option>O(+ve)</option>
           <option>O(-ve)</option>
       </select>
       <span>Gender (লিঙ্গ): </span>
       <select class="sex" name="sex">
           <option>Gender</option>
           <option>M</option>
           <option>F</option>
       </select>
       <span>Monthly Salary (মাসিক বেতন): </span>
       <input type="number" name="salary" placeholder="Salary" required>
       <span>Mobile Number (মেবাইল নাম্বার): </span>
       <input type="number" name="phone" placeholder="Mobile number" required>
       <span>Email Address (ইমেল ঠিকানা): </span>
       <input type="email" name="mail" placeholder="Email" required>
       <span>Full Address (স্থায়ী ঠিকানা): </span>
       <input type="text" name="address" placeholder="Addres" required>
       <span>Date of Birth (জন্ম তারিখ): </span>
       <input type="text" id="dob" name="bdate" placeholder="Date of Birth" required>
       <span>Age (বয়স): </span>
       <input type="number" id="age" name="age" placeholder="Age" readonly>
       <span>Joinig Date (যোগদানের তারিখ): </span>
       <input type="text" id="dob" name="jdate" placeholder="Joining Date" required>
       <input type="reset" name="reset" value="Clear">
       <input type="submit" name="submit" value="Get ID">
     </form>
   </div>
 <!--
 <div class="footer">
  <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
 </div>-->
   </body>
 </html>
