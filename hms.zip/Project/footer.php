<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>footer</title>
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="footer" style="position:absolut; bottom: 0;">
     <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
    </div>
  </body>
</html>
