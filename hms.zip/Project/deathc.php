<?php require('session.php'); ?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT * FROM death_report WHERE `did`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $name =$row['name'];
    $dob=$row['dob'];
    $ddob=$row['dod'];
    $dtime=$row['tod'];
    $gender=$row['sex'];
    $did=$row['did'];
    $casue=$row['dcase'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Death Certificate</title>
    <link rel="stylesheet" href="css/deathc.css">
    <script type="text/javascript">
    function printDiv(main) {
  var printContents = document.getElementById(main).innerHTML;
  var originalContents = document.body.innerHTML;

  document.body.innerHTML = printContents;

  window.print();

  document.body.innerHTML = originalContents;
}
</script>
  </head>
  <body>
    <div class="back" style="margin-left:15%;margin-top:15px; border:1px solid dodgerblue; width:40px; text-align:center; background-color:lightgray;"><a href="deathreport.php" style="text-decoration:none;font-weight:bold;">Back</a></div>
    <div id="printableArea" class="main">
      <input type="button" onclick="printDiv('printableArea')" value="print" />
      <div class="no">
        <p>Certificate No: <?php echo $did;?></p>
      </div>
      <div class="hsname">
                  <h2>Hopital Name</h2>
      </div>
      <div class="header">

          <img src="imge/gov.png" alt="" height="100px" width="160px;"><br>
          <img id= "re" src="imge/death.jpg" alt="" height="60px" width="300px" style="border-radius:20px;">

      </div>

      <div class="details">
        <p>This is to certify that the records in my office show that <br>
          Mr./Miss/Mrs.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b> <?php echo $name;?></b><br>
          Died of &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b> <?php echo $dtime;?> </b> &nbsp;&nbsp;&nbsp; on &nbsp;&nbsp;&nbsp; <b><?php echo $ddob;?></b><br>
          Gender-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b><?php echo $gender;?></b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          Cause of Death- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $casue;?></b> <br><br>
          I have hereunto affixed my signature alongside a witness on <?php echo $ddob;?> <br>

          <br> We are issuing the Certificate on the specific request of &nbsp;&nbsp;&nbsp;<b> <?php echo $name;?></b> &nbsp;&nbsp;&nbsp;without accepting any liability on behalf of this Certificate of part of this on our Hospital.<br>
          <br><br>
          [Authority]<br>
          ------------- <br>

      </div>
    </div>
  </body>
</html>
