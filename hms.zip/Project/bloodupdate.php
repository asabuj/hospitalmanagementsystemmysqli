<?php

include('dbconnect.php');
if (isset($_POST['submit']))

$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT SUM(present_blood) FROM bloodbank";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection_update);

//Update the data and Save it into the MySQL database;
/*
if (isset($_POST['submit'])) {
  $user = 'root';
  $password = '';
  $ip = 'localhost';
  $dbname = 'project';
  $use=$row['upac'];
  $connection_write = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "SELECT `use_blood` SUM `use_blood`='{$use}' WHERE `id`='{A(+ve)}' ";
    $result= mysql_query("SELECT SUM(orders) FROM CustomerOrders WHERE `present_blood` = '{A(+ve)}'");
    if(mysqli_query($connection_write, $query)){
      echo "<b><script>alert('SUCCESS : use successfully');</script></b>";
      echo "<script>window.location.href = 'blood.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_write);
}*/
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="#" method="post">
      <input type="number" name="upac" placeholder="Use">
      <input type="submit" name="submit" value="Use">
    </form>
  </body>
</html>
