<?php
require('session.php');
 ?>
<?php
include('../dbconnect.php');
  if(isset($_POST['submit'])){
    $dname = $_POST['name'];
    $age = $_POST['age'];
    $visitdate = $_POST['vdate'];
    $problem = $_POST['problem'];
    $test = $_POST['test'];
    $nextday = $_POST['nextday'];
    $sql_read = "SELECT `id` FROM pers";
    $sl_no = 0;
    $result = mysqli_query($connection,$sql_read);
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
    }
    $last_id = $sl_no;
    $last_id = $last_id + 1;
    $date = date('d-m-Y');
    $day=date("d",strtotime($date));
    $month=date("m",strtotime($date));
    $year=date("Y",strtotime($date));
    $whole_date=$year.$month.$day;
    $unique_id="PRE-".$whole_date.$last_id;
    $query = "INSERT INTO `pers` (`name`, `age`, `vdate`, `problem`, `test`, `ref`, `nday`, `visible`) VALUES('{$dname}', '{$age}', '{$visitdate}', '{$problem}','{$test}', '{$unique_id}', '{$nextday}', '{$visibility}')";
    if(!mysqli_query($connection, $query)){
      echo "<script>alert('ERROR : Unique ID Generation Failed');</script>";
    }else{
      echo "<b><script>alert('SUCCESS : successfully');</script></b>";
      echo "<script>window.location.href = 'prescriptionlist.php'</script>";
    }
    mysqli_close($connection);
    }


 ?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Prescription</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/rabon1.css">
    <link rel="stylesheet" href="css/stylephp.css">
    <script src="js/navbarclock.js"></script>
</head>
  <body onload="startTime()" >
    <!--Hospital Name start-->
    <div class="name">
      <div class="dclock">
      <div class="datee"><?php echo date('l, F j, Y'); ?></div>
      <div id="clock"></div>
    </div>
      <div class="hname"><h2>Hospital Management System</h2></div>

    </div>
    <!--Hospital Name End-->
    <!--1st header-->
      <div class="header">

        <div class="admin">
          <h1><?php
          include('../dbconnect.php');
            if (!mysqli_connect_errno()) {
              $query = "SELECT * FROM doclog WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);

              if($result){
                echo "Current User:-" ."<i>".$row['name']. "</i>" .", ". "Your ID-". $row['id'];
              }
            }?></h1>
        </div>
        <div class="logout">
          <a href="dhome.php">Home</a>
          <a href="appoitmentlist.php">Appointment</a>
          <a  class ="active" href="prescriptionlist.php">Perscription</a>
          <a href="operationlist.php">Operation</a>
          <a href="test.php">Test</a>
          <a href="../logout.php">Logout</a>
        </div>
    </div>
      <!--1st header end-->

      <!--Home page menue start-->

      <!--Home page menue End-->
<!--appoinment Form-->
<div class="non-semantic-protector">
         <h1 class="ribbon">
           <strong class="ribbon-content">Create Prescription</strong>
         </h1>
 </div>
 <div class="main">
   <form class="form_div" action="#" method="post">
     <?php
     include('../dbconnect.php');
     echo "<span>"."Patient Name:"."</span>";
     echo "<select class= 'sex' name= 'name'>";
     echo '<option >'.'--- Select Patient Name ---'.'</option>';
     $query = mysqli_query($connection,"SELECT name FROM adpatient WHERE visible=1");
     $query_display = mysqli_query($connection,"SELECT * FROM adpatient WHERE visible=1");
     while($row=mysqli_fetch_array($query))
     {
         echo "<option ". $row['id']."'>".$row['name']
      .'</option>';
     }
     echo '</select>';
     ?>
     <span>Age: </span>
     <input type="number" name="age" placeholder="Age">
     <span>Date: </span>
     <input type="date" name="vdate">
     <span>Problem Task:</span>
     <textarea name="problem" placeholder="Problem"></textarea>
     <span>Test:</span>
     <textarea name="test" placeholder="Test"></textarea>
     <span>Next Visiting Day:</span>
     <input type="date" name="nextday">
     <input type="submit" name="submit" value="Get ID" style="margin-left:35%;">
   </form>
 </div>
<div class="footer">
 <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
</div>

  </body>
</html>
