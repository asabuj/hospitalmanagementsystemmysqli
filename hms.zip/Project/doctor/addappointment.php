<?php
require('session.php');
 ?>
<?php
include('function.php');
include('../dbconnect.php');
  if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $fee = $_POST['fee'];
    $vdate = $_POST['vdate'];
    $vtime = $_POST['vtime'];
    $gender = $_POST['sex'];
    $command = $_POST['commant'];
    $sql_read = "SELECT `id` FROM appoint";
    $sl_no = 0;
    $result = mysqli_query($connection,$sql_read);
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
    }
    $last_id = $sl_no;
    $last_id = $last_id + 1;
    $date = date('d-m-Y');
    $day=date("d",strtotime($date));
    $month=date("m",strtotime($date));
    $year=date("Y",strtotime($date));
    $whole_date=$year.$month.$day;
    $unique_id="APP-".$whole_date.$last_id;
    // Insert the Unique ID into the Database in its specific column of the table
    $sql_write = "INSERT INTO `appoint` (`name`, `fee`, `vdate`, `vtime`, `gender`, `commant`, `appid`, `visible`) VALUES('{$name}', '{$fee}', '{$vdate}', '{$vtime}','{$gender}','{$command}', '{$unique_id}', '{$visibility}')";
    if(!mysqli_query($connection, $sql_write)){
      echo "<script>alert('ERROR : Failed Please Try Again')</script>";
    }else{
      echo "<b><script>alert('SUCCESS : successfully');</script></b>";
      echo "<script>window.location.href = 'appoitmentlist.php'</script>";
    }
    mysqli_close($connection);
  }



 ?>
 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <title>Appointment</title>
     <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="css/rabon1.css">
     <link rel="stylesheet" href="css/stylephp.css">
     <script src="js/navbarclock.js"></script>
 </head>
   <body onload="startTime()" >
     <!--Hospital Name start-->
     <div class="name">
       <div class="dclock">
       <div class="datee"><?php echo date('l, F j, Y'); ?></div>
       <div id="clock"></div>
     </div>
       <div class="hname"><h2>Hospital Management System</h2></div>

     </div>
     <!--Hospital Name End-->
     <!--1st header-->
       <div class="header">

           <div class="admin">

             <h1><?php
             include('../dbconnect.php');
               if (!mysqli_connect_errno()) {
                 $query = "SELECT * FROM doclog WHERE `visible` = 1";
                 $result = mysqli_query($connection, $query);

                 if($result){
                   echo "Current User:-" ."<i>".$row['name']. "</i>" .", ". "Your ID-". $row['id'];
                 }
               }?></h1>
           </div>
           <div class="logout">
             <a href="dhome.php">Home</a>
             <a class ="active" href="appoitmentlist.php">Appointment</a>
             <a href="prescriptionlist.php">Perscription</a>
             <a href="operationlist.php">Operation</a>
             <a href="test.php">Test</a>
             <a href="../logout.php">Logout</a>
           </div>
       </div>
       <!--1st header end-->

       <!--Home page menue start-->
       <div class="menue">
         <a href="appoitmentlist.php">Appointmentlist</a>
         <a href="#">Pending Appointment</a>
         <a href="#">Upcoming Appointment</a>
         <a href="#">Complete Appointment</a>

       </div>
       <!--Home page menue End-->
       <!--Appointment Form-->
 <div class="non-semantic-protector">
          <h1 class="ribbon">
            <strong class="ribbon-content">Add New Appointment</strong>
          </h1>
  </div>
  <div class="main">
    <form class="form_div" action="#" method="post">
    <?php
    include('../dbconnect.php');
    //=============================
    //This creates the drop down box
    echo "<span>"."Patient Name:"."</span>";
    echo "<select class= 'sex' name= 'name'>";
    echo '<option >'.'--- Select Patient Name ---'.'</option>';
    //$query=mysqli_query($con,"SELECT id,FirstName FROM persons");
    $query = mysqli_query($connection,"SELECT name FROM adpatient");
    $query_display = mysqli_query($connection,"SELECT * FROM adpatient");
    while($row=mysqli_fetch_array($query))
    {
        echo "<option ". $row['id']."'>".$row['name']
     .'</option>';
    }
    echo '</select>';
    ?>
    <span>Visiting Fee: </span>
      <input type="text" name="fee" placeholder="Visiting Fee" required>
      <span>Visiting Date:</span>
      <input type="date" name="vdate" placeholder="Visiting Date" required>
      <span>Visiting Time:</span>
      <input type="time" name="vtime" placeholder="Visiting Time" required>
      <span>Gender:</span>
      <select class="sex" name="sex">
          <option>Gender</option>
          <option>M</option>
          <option>F</option>
      </select>
      <span>Problem Task: </span>
      <textarea name="commant" placeholder="Porblem task"></textarea>

      <input type="reset" name="reset" value="Clear">
      <input type="submit" name="submit" value="Get ID">
    </form>
  </div>
  <!--

   </body>
 </html>
