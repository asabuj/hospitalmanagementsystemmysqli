<?php
require('session.php');
 ?>
<?php
include('../dbconnect.php');
  if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $tname = $_POST['tname'];
    $fee = $_POST['fee'];
    $tdate = $_POST['tdate'];
    $sql_read = "SELECT `id` FROM test";
    $sl_no = 0;
    $result = mysqli_query($connection,$sql_read);
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
    }
    $last_id = $sl_no;
    $last_id = $last_id + 1;
    $date = date('d-m-Y');
    $day=date("d",strtotime($date));
    $month=date("m",strtotime($date));
    $year=date("Y",strtotime($date));
    $whole_date=$year.$month.$day;
    $unique_id="TE-".$whole_date.$last_id;
    // Insert the Unique ID into the Database in its specific column of the table
    $sql_write = "INSERT INTO `test` (`sid`, `name`, `tname`, `fee`, `tdate`, `visible`) VALUES('{$unique_id}', '{$name}', '{$tname}', '{$fee}', '{$tdate}', '{$visibility}')";
    if(!mysqli_query($connection, $sql_write)){
      echo "<script>alert('ERROR : ADD Unsuccessful');</script>";
    }else{
      echo "<b><script>alert('SUCCESS : successfully');</script></b>";
      echo "<script>window.location.href = 'test.php'</script>";
    }
    mysqli_close($connection);
  }



 ?>
 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <title>Add Test</title>
     <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="css/rabon1.css">
     <link rel="stylesheet" href="css/stylephp.css">
     <script src="js/navbarclock.js"></script>
 </head>
   <body onload="startTime()" >
     <!--Hospital Name start-->
     <div class="name">
       <div class="dclock">
       <div class="datee"><?php echo date('l, F j, Y'); ?></div>
       <div id="clock"></div>
     </div>
       <div class="hname"><h2>Hospital Management System</h2></div>

     </div>
     <!--Hospital Name End-->
     <!--1st header-->
       <div class="header">

         <div class="admin">
           <h1><?php
           include('../dbconnect.php');
             if (!mysqli_connect_errno()) {
               $query = "SELECT * FROM doclog WHERE `visible` = 1";
               $result = mysqli_query($connection, $query);

               if($result){
                  echo "Current User:-" ."<i>".$row['name']. "</i>" .", ". "Your ID-". $row['id'];
               }
             }?></h1>
         </div>
         <div class="logout">
           <a href="dhome.php">Home</a>
           <a href="appoitmentlist.php">Appointment</a>
           <a href="prescriptionlist.php">Perscription</a>
           <a href="operationlist.php">Operation</a>
           <a  class ="active" href="test.php">Test</a>
           <a href="../logout.php">Logout</a>
         </div>
     </div>
       <!--1st header end-->

       <!--Home page menue start-->
       <div class="menue">
        <a href="test.php">View test</a>

       </div>
       <!--Home page menue End-->

 <!--Test Form-->
 <div class="non-semantic-protector" style="margin-top:-60px;">
          <h1 class="ribbon">
            <strong class="ribbon-content">ADD New Test</strong>
          </h1>
  </div>
  <div class="main">
    <form class="form_div" action="#" method="post">
    <?php
    include('../dbconnect.php');
    echo "<span>"."Patient Name:"."</span>";
    echo "<select class= 'sex' name= 'name'>";
    echo '<option >'.'--- Select Patient Name ---'.'</option>';
    $query = mysqli_query($connection,"SELECT name FROM adpatient WHERE visible=1");
    $query_display = mysqli_query($connection,"SELECT * FROM adpatient WHERE visible=1");
    while($row=mysqli_fetch_array($query))
    {
        echo "<option ". $row['id']."'>".$row['name']
     .'</option>';
    }
    echo '</select>';
    ?><br><br>
    <span>Test Name</span>
      <select class= "sex" name= "tname">
      <option>Select Test</option>
      <option>BLood</option>
      <option>Exray</option>
      <option>ECG</option>
      <option>Others</option>
      </select><br><br>
    <span>Test Fee</span>
      <input type="text" name="fee" placeholder="Operation Fee" required><br><br>
      <span>Test Date</span>
      <input type="date" name="tdate" required><br>
      <input type="reset" name="reset" value="Clear">
      <input type="submit" name="submit" value="Save">
    </form>
  </div>
  <!--

   </body>
 </html>
