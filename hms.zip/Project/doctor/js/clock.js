function startTime() {
	var extension = "am";
  var today = new Date();
  var hours = today.getHours();
  var minutes = today.getMinutes();
  var seconds = today.getSeconds();
  minutes = checkTime(minutes);
  seconds = checkTime(seconds);
  if(hours > 12)
  {
	  hours = hours-12;
	  extension = "pm";
	  
  }
  
  document.getElementById('a1').innerHTML = hours + ":" + minutes + ":" + seconds + extension;
  var t = setTimeout(startTime, 100);
}
function checkTime(i) {
  if (i < 10) {
    i = "0" + i;
  }
  return i;
}
