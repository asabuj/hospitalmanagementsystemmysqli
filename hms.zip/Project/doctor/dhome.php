<?php
require('session.php');
 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Home</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/navbarclock.js"></script>
</head>
  <body onload="startTime()" >
    <!--Hospital Name start-->
    <div class="name">
      <div class="dclock">
      <div class="datee"><?php echo date('l, F j, Y'); ?></div>
      <div id="clock"></div>
    </div>
      <div class="hname"><h2>Hospital Management System</h2></div>

    </div>
    <!--Hospital Name End-->
    <!--1st header-->
      <div class="header">

          <div class="admin">
            <h1><?php
            include('../dbconnect.php');
              if (!mysqli_connect_errno()) {
                $query = "SELECT * FROM doclog WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);

                if($result){
                  echo "Current User:-" ."<i>".$row['name']. "</i>" .", ". "Your ID-". $row['id'];
                }
              }?></h1>
          </div>
          <div class="logout">
            <a  class ="active" href="dhome.php">Home</a>
            <a href="appoitmentlist.php">Appointment</a>
            <a href="prescriptionlist.php">Perscription</a>
            <a href="operationlist.php">Operation</a>
            <a href="test.php">Test</a>
            <a href="../logout.php">Logout</a>
          </div>
      </div>
      <!--1st header end-->

      <!--Home page menue End-->
      <!--Analog Clock-->
<div class="wellcome">
<center><h3>The confusion with doctor discharge instructions</h3></center>
<p>
More than 78 percent of patients do not fully understand the discharge instructions given by the doctor in the ER, according to a study in the Annals of Emergency Medicine. This is actually not too surprising. The ER is a chaotic, noisy, disorienting place.
Furthermore, the doctor is often in a hurry (the next patient is already waiting and potentially unstable), harried, and under stress. Meanwhile, the patient receiving the information is often ill, elderly, a minor, mentally challenged, under stress, out of his or her usual element, or otherwise just not optimally receptive.<br>
Under ideal conditions, my own practice is to explain my instructions to the patient (and family), then have the nurse explain them again and give them a written copy to take with them.<br>

<b>You would think this should work. However, conditions are almost never ideal in the ER.</b><br>
I often find the written instruction sheets floating across the parking lot in the wind on my way to the car at the end of a shift. On the occasions when I have stopped at the end of my discharge explanation and asked the patient to repeat it to me, I have rarely received the same information back. Sometimes intelligence is an issue. More often it is just plain difficult for even the smartest patient to absorb and remember what is being said under these adverse conditions.<br>
Although the ER may be the extreme case for this issue it may apply equally in the clinic setting or even a doctor's office. How can we -- both doctors and patients -- deal with this situation?
<br>
First, written instructions are important to deal with the memory issue. Almost no one can remember all of what is being said in a complicated interchange of this sort. It would be great for the patients to make notes on the discharge documents. I have never seen a patient do this. I, of course, almost always do it, but the patient may not understand my notes.

Second, it helps to have another set of ears in the room. A family member or health advocate who is not the direct object of the instructions is often better equipped to hear and interpret the doctor's instructions. Patients often hear only what they want to or are prepared to hear.

Finally, it is never a bad idea to ask questions about anything you don't fully understand. You can even call back later for clarification. If you cannot reach the doctor who treated you, another doctor can usually explain the instructions.

Very often the most valuable thing you are getting in the doctor / patient exchange is the doctor's opinion and instructions. Don't leave for home without it.
</p>

</div>
<div class="footer">
 <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
</div>

  </body>
</html>
