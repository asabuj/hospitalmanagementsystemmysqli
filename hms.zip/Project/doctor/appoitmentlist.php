<?php
require('session.php');
 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Appointment</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/rabon1.css">
    <link rel="stylesheet" href="css/stylephp.css">
    <script src="js/navbarclock.js"></script>
</head>
  <body onload="startTime()" >
    <!--Hospital Name start-->
    <div class="name">
      <div class="dclock">
      <div class="datee"><?php echo date('l, F j, Y'); ?></div>
      <div id="clock"></div>
    </div>
      <div class="hname"><h2>Hospital Management System</h2></div>

    </div>
    <!--Hospital Name End-->
    <!--1st header-->
      <div class="header">
        <div class="admin">
          <h1><?php
          include('../dbconnect.php');
            if (!mysqli_connect_errno()) {
              $query = "SELECT * FROM doclog WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);

              if($result){
                echo "Current User:-" ."<i>".$row['name']. "</i>" .", ". "Your ID-". $row['id'];
              }
            }?></h1>
        </div>
        <div class="logout">
          <a href="dhome.php">Home</a>
          <a class ="active" href="appoitmentlist.php">Appointment</a>
          <a href="prescriptionlist.php">Perscription</a>
          <a href="operationlist.php">Operation</a>
          <a href="test.php">Test</a>
          <a href="../logout.php">Logout</a>
        </div>
    </div>
      <!--1st header end-->

      <!--Home page menue start-->
      <div class="menue">
        <a href="addappointment.php">Add Appointment</a>

      </div>
      <!--Home page menue End-->

<!--appoinment Form-->
<div class="non-semantic-protector" style="margin-top: -60px;">
         <h1 class="ribbon">
           <strong class="ribbon-content">All Appointment List</strong>
         </h1>
 </div>
 <form method="post" action="appoitmentlist.php" style="margin-top: -50px;padding: 4px;">
   <input  type="text" name="sabuj" placeholder="Check Your..." style="border:1px solid lightgray; border-radius: 6px;">
   <select name="column" style="border:1px solid lightgray; border-radius: 6px;height:30px;">
     <option value="">--Select--</option>
     <option value="dname">Name</option>
     <option value="appid">App ID</option>
   </select>
   <input type="submit" name="submit" value="Check" style="border-radius:3px;width:80px;border:1px solid lightgray;margin-left:0px; font-weight:bold;" >
 </form>
 <?php
 include('../dbconnect.php');
 	if (isset($_POST['submit'])) {
 		$sabuj = $connection->real_escape_string($_POST['sabuj']);
 		$column = $connection->real_escape_string($_POST['column']);
 		if ($column == "" || ($column != "dname" && $column != "appid"))
 			$column = "dname" && "appid";
 		$sql = $connection->query("SELECT * FROM appoint WHERE $column LIKE '%$sabuj%' AND visible=1");
 		if ($sql->num_rows > 0) {
 			while ($data = $sql->fetch_array())
 				{  $id=$data['id'];
          echo "Full Name-".$data['dname'].", "."Appointment ID-".$data['appid']."<a href = 'printappointment.php?id=$id' style='text-decoration: none;margin-left: 2%;border: 1px solid lightblue;padding: 2px 20px;border-radius: 3px;'>View</a>"."<br>";
        //  echo "Name-".$data['name'].", "."ID-". $data['id'].", "."Appint No-". $data['appid']."<a href = 'printappointment.php?id=$id'>View</a>"."<br>"};

 		}
  }else
 			echo "<b>"."Data Not Valid, Check Again"."</b>";
 	}

 ?>
 <br>
 <?php
 include('function.php');
 include('../dbconnect.php');
   if (!mysqli_connect_errno()) {
     $query = "SELECT * FROM appoint WHERE `visible` = 1";
     $result = mysqli_query($connection, $query);

     if($result){
       echo "<table id='tbl'>
     <tr>
       <th>Sl. No.</th>
       <th>Doctor Name</th>
       <th>Patient Name</th>
       <th>Fee</th>
       <th>Visiting Date</th>
       <th>Visiting Time</th>
       <th>Gender</th>
       <th>Problem</th>
       <th>Appointment Id</th>
       <th>View</th>
     </tr> ";
     "<tbody style='height: 200px; display: block; overflow: auto;'></tbody>";
       $sl_no = 0;
     while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
       $sl_no = $sl_no + 1;
       $id = $row['id'];
       echo "<tr>";
       echo "<td>".$sl_no."</td>";
       echo "<td style='text-align:left;width:19%'>".ucwords($row['dname'])."</td>";
       echo "<td style='text-align:left;width:19%'>".ucwords($row['name'])."</td>";
       echo "<td>".$row['fee']."</td>";
       echo "<td>".$row['vdate']."</td>";
       echo "<td>".$row['vtime']."</td>";
       echo "<td>".$row['gender']."</td>";
       echo "<td>".$row['commant']."</td>";
       echo "<td>".$row['appid']."</td>";
       echo "<td style = 'width:100px;'>"."<a href = 'printappointment.php?id=$id' id='update'>View</a>"."</td>";
       echo "</tr>";
   }
 echo "</table>";
 }
   }else{
     die("ERROR : ".mysqli_connect_error());
   }
   mysqli_close($connection);
  ?>
<!-- Footer Area-->
<div class="footer">
 <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
</div>
  </body>
</html>
