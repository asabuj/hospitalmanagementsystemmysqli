<?php
session_start();
include('../dbconnect.php');
$user_check = $_SESSION['doclog'];
$ses_sql = mysqli_query($connection,"SELECT * FROM doclog WHERE `username` = '{$user_check}' ");
$row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
$login_session = $row['username'];
if(!isset($_SESSION['doclog'])){
  header("location:../index.php");
}
?>
