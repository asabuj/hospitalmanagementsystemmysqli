<?php
require('session.php');
 ?>


 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <title>Print Prescription</title>
     <link rel="stylesheet" href="css/prescription.css">
     <script type="text/javascript">
     function printDiv(main) {
   var printContents = document.getElementById(main).innerHTML;
   var originalContents = document.body.innerHTML;

   document.body.innerHTML = printContents;

   window.print();

   document.body.innerHTML = originalContents;
}
     </script>
   </head>
   <body>

<div class="back" style="margin-left:15%;margin-top:15px; border:1px solid dodgerblue; width:40px; text-align:center; background-color:lightgray;"><a href="prescriptionlist.php" style="text-decoration:none;font-weight:bold;">Back</a></div>
     <div id="printableArea" class="main">
       <input type="button" onclick="printDiv('printableArea')" value="print" />
       <!--Header Are-->
       <div class="header">

         <div class="dname">
           <?php
           include('../dbconnect.php');
             if (!mysqli_connect_errno()) {
               $query = "SELECT * FROM doclog WHERE `visible` = 1";
               $result = mysqli_query($connection, $query);

               if($result){
                 echo "<i style='margin-left: 5%;margin-top: 19%;font-size:25px; hidden;float: left;''>". "Dr." .$row['name']. "</i>";
               }
             }?>
         </div>
         <div class="dadd">
           <h2>(Chamber Name)</h2>
           <p>(Chamger Address,)<br>(Chamber Phone)</p>
         </div>
         <div class="hosname">
           <h2>Dr. Ashikur Rahman</h2>
             <p>MBBS, DBBMS(Dhaka)<br>Dhaka Medical College and Hospital, Dhaka, Mobile: 0172342516</p>
         </div>
         <?php
         include('../dbconnect.php');
         $id = $_GET['id'];
         if (!mysqli_connect_errno()){
           $query = "SELECT `name`,`age`,`vdate`, `ref` FROM pers WHERE `id`='{$id}'";
           $result = mysqli_query($connection,$query);
           if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
             $name=$row['name'];
             $age=$row['age'];
             $vdate=$row['vdate'];
             $ref = $row['ref'];
           }
         }else{
           echo "ERROR : Database connection failed !"."<br>";
         }
         mysqli_close($connection);
          ?>
         <div class="patainet">

           <b><p>Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp<i><?php echo $name; ?></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Age:     <i><?php echo $age; ?></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>Date:    <i><?php echo $vdate; ?></i></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>Reference No:&nbsp;&nbsp;<i><?php echo $ref;?></i></p></b>

         </div>
       </div>
       <!--End of Header Area-->
       <div class="pright">
           <center><b>Problem</b></center>
           <p>Headace for PHP</p><br>
           <br>
           <br>
           <br>
           <center><h4>Test</h4></chenter>
             <p>Head Refresh</p>
       </div>
       <div class="medicne">
         <div class="rx">
         <strong><i>Rx_</i></strong><br>
         <br>
         <br>
         1. Rest for 24 hours.<br>
         <br>
         <br>
         2. Take Jurney after rest.
         </div>
         <div class="next">
           <p>Next Visiting day:</p>
         </div>
       </div>

     </div>
   </body>
 </html>
