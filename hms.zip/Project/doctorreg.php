<?php
require('session.php');
 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Profile Management</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/stylephp.css">
    <script src="js/clock.js" charset="utf-8"></script>
    <script src="js/calander.js" charset="utf-8"></script>

</head>
  <body onload="displayCalendar(),startTime()" >
    <!--Hospital Name start-->
    <div class="name">
      <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
      <div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
      <h2>Hospital Management System</h2>
    </div>
    <!--Hospital Name End-->
    <!--1st header-->
      <div class="header">
          <div class="admin">
            <marquee behavior="alternate" scrollamount="2s"><h4><?php
            include('dbconnect.php');
              if (!mysqli_connect_errno()) {
                $query = "SELECT * FROM user WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);

                if($result){
                  echo "Current User:-".$row['username'];
                }
              }?></h4></marquee>
          </div>
          <div class="logout">
            <a href="home.php">Home</a>
            <a href="doctor.php">Doctor's</a>
            <a href="nurse.php">Nurse</a>
            <a href="patient.php">Patient's</a>
            <a href="pharmacist.php">Pharamacist</a>
            <a href="labrotorist.php">Laboratist</a>
            <a href="accounts.php">Account's</a>
            <a  class= "active" href="profile.php">Profile</a>
            <a href="logout.php">Logout</a>
          </div>
      </div>
      <!--1st header end-->

      <!--Home page menue start-->
      <div class="menue">
        <a href="appoitmentlist.php">Appoinment</a>
        <a href="blood.php">Bloodbank</a>
        <a href="medicine.php">Medicine</a>
        <a href="operationlist.php">Operation's</a>
        <a href="birthreport.php">Birth Report</a>
        <a href="deathreport.php">Death Report</a>
        <a href="beddetails.php">Bed Status </a>
      </div>
      <!--Home page menue End-->
      <!--Analog Clock-->
      <div id="sabuj">
      <h1>Current Time</h1>
      <div id="a1"></div>
      </div>
      <!--Calander-->
      <div class="calander">
      	<div id="calendar"></div>
      </div>
<div class="wellcome" style="margin:0 auto; margin-top:20px;border:none;">
  <?php
  include('dbconnect.php');
  if (isset($_POST['submit'])){
    $dname = $_POST['name'];
    $specility = $_POST['special'];
    $email =$_POST['mail'];
    $uname = $_POST['uname'];
    $psw = $_POST['psw'];
    if(!mysqli_connect_errno()){
      $query = "INSERT INTO `doclog` (`name`, `special`, `mail`, `username`, `password`, `visible`) VALUES('{$dname}', '{$specility}', '{$email}', '{$uname}', '{$psw}', '{$visibility}')";
      if(mysqli_query($connection, $query)){
        echo "<b><script>alert('SUCCESS : User Add successfully ');</script></b>";
        echo "<script>window.location.href = 'profile.php'</script>";
      }else{
        echo "<b><script>alert('SUCCESS : Add User Unsuccessful, Your user name or mail already exist');</script></b>";
        echo "<script>window.location.href = 'doctorreg.php'</script>";
      }
    }else{
      die("ERROR : ".mysqli_connect_errno());
    }
    mysqli_close($connection);
  }

   ?>
   <form class="form_div" action="#" method="post">
     <span>Full Name: </span><input type="text" name="name"><br><br>
     <span>Speciality: </span>
     <select class="sex" name="special">
         <option>Specilization</option>
         <option>Neurologist</option>
         <option>Cardiology</option>
         <option>Colorectal Surgery</option>
         <option>Gynaecology </option>
         <option>Obstetrics</option>
         <option>Spinal Surgery</option>
         <option>Ophthalmology</option>
         <option>Paediatrics</option>
         <option>Gastroenterology</option>
         <option>Endocrinology</option>
         <option>Dermatology</option>
         <option>Urology</option>
         <option>Medicine</option>
         <option>Nephrology</option>
         <option>Psychiatry</option>
     </select><br><br>
     <span>Email Address:</span><input type="email" name="mail" required><br><br>
     <span>Choose User Name: </span><input type="text" name="uname"><br><br>
     <span>Password:</span><input type="password" name="psw" value=""><br><br>
     <input type="submit" name="submit" value="Create User" style="margin-left:40%;"><br>
      <a href="profile.php">Back</a>
   </form>
</div>
<div class="footer">
 <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
</div>

  </body>
</html>
