<?php require('session.php'); ?>
<?php
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT * FROM adpatient WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $bed_id =$row['bed_id'];
    $pname=$row['name'];
    $pproblem=$row['problem'];
    $pgender=$row['gender'];
    $page=$row['age'];
    $pbloodgroup=$row['bloodgroup'];
    $paddress = $row['address'];
    $pmobile = $row['mobile'];
    $pjdate = $row['jdate'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}

//Update the data and Save it into the MySQL database;
$bed = "SELECT * FROM bed";
$all_bed = mysqli_query($connection, $bed);
if (isset($_POST['save'])) {
  $bed_id =$_POST['bed_id'];
  $name=$_POST['name'];
  $problem=$_POST['problem'];
  $gender=$_POST['gender'];
  $age=$_POST['age'];
  $bloodgroup=$_POST['bloodgroup'];
  $address = $_POST['address'];
  $mobile = $_POST['mobile'];
  $jdate = $_POST['jdate'];
  if (!mysqli_connect_errno()) {
    $query = "UPDATE adpatient SET `bed_id`='{$bed_id}', `name`='{$name}', `problem`='{$problem}', `gender`='{$gender}', `age` = '{$age}', `bloodgroup` = '{$bloodgroup}', `room` = '{$room}', `bed`= '{$bed}', `address` = '{$address}', `mobile` = '{$mobile}', `jdate` = '{$jdate}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'patient.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection);
}

 ?>
 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <title>Update Patient</title>
     <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="css/rabon.css">
     <link rel="stylesheet" href="css/stylephp.css">
     <script src="js/clock.js" charset="utf-8"></script>
     <script src="js/calander.js" charset="utf-8"></script>
 </head>
 <body onload="displayCalendar(),startTime()">
   <!--Hospital Name start-->
   <div class="name">
     <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
     <div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
     <h2>Hospital Management System</h2>
   </div>
   <!--Hospital Name End-->
   <!--1st header-->
   <div class="header">
       <div class="admin">

       </div>
       <div class="logout">
         <a href="home.php">Home</a>
         <a href="doctor.php">Doctor's</a>
         <a href="nurse.php">Nurse</a>
         <a class= "active" href="patient.php">Patient's</a>
         <a href="pharmacist.php">Pharamacist</a>
         <a href="labrotorist.php">Laboratist</a>
         <a href="accounts.php">Account's</a>
         <a href="profile.php">Profile</a>
         <a href="logout.php">Logout</a>
       </div>
   </div>
   <!--1st header end-->

   <!--Home page menue start-->
   <div class="menue">
     <a href="appoitmentlist.php">Appoinment</a>
     <a href="medicine.php">Medicine</a>
     <a href="operationlist.php">Operation's</a>
     <a href="blood.php">Bloodbank</a>
     <a href="birthreport.php">Birth Report</a>
     <a href="deathreport.php">Death Report</a>
     <a href="beddetails.php">Bed Status </a>
   </div>
   <!--Home page menue End-->
       <!--Analog Clock-->
       <div id="sabuj">
       <h1>Courrent Time</h1>
       <div id="a1"></div>
       </div>
       <!--Calander-->
       <div id="calendar"></div>
 <!-- Update Patient-->
 <div class="submenu">
   <a href="patient.php">Back Patient List</a>
 </div>
 <div class="non-semantic-protector">
         	<h1 class="ribbon">
         		<strong class="ribbon-content">Update Patient</strong>
         	</h1>
 </div>
       <div class="main">
           <form class="form_div" action="#" method="post">
             <span>Select Ward</span>
             <select class="sex" name="bed_id">
                 <?php
                 while ($row = mysqli_fetch_assoc($all_bed)) {
                     ?>
                     <option value="<?php echo $row['bed_id'] ?>"><?php echo $row['bedname'] ?></option>
                 <?php } ?>
             </select>
             <span>Patient Name:</span>
             <input type="text" name="name" value="<?php echo $pname; ?>" placeholder="Patient Name">
             <span>Problem:</span>
             <input type="text" name="problem" value="<?php echo $pproblem; ?>" placeholder="Problem">
             <span>Gender:</span>
             <select class="sex" name="gender" value="<?php echo $pgender;?>">
                 <option>Gender</option>
                 <option>M</option>
                 <option>F</option>
             </select>
             <span>Patient Age:</span>
             <input type="number" name="age" value="<?php echo $page; ?>" placeholder="Age">
             <span>Blood Group:</span>
             <select class="sex" name="bloodgroup" value="<?php echo $pbloodgroup; ?>">
                 <option>Blood Group</option>
                 <option>A(+ve)</option>
                 <option>A(-ve)</option>
                 <option>B(+ve)</option>
                 <option>B(-ve)</option>
                 <option>AB(+ve)</option>
                 <option>AB(-ve)</option>
                 <option>O(+ve)</option>
                 <option>O(-ve)</option>
                 <option>N/A</option>
             </select>
             <span>Full Address</span>
             <input type="text" name="address" value="<?php echo $paddress; ?>" placeholder="Patient address">
             <span>Mobile NO:</span>
             <input type="number" name="mobile" value="<?php echo $pmobile; ?>" placeholder="Mobile No">
             <span>Joining Date:</span>
             <input type="date" name="jdate" value="<?php echo $pjdate; ?>" placeholder="joining DAte"><br>
             <input type="submit" name="save" value="save" style="margin-left:40%;">
           </form>
       </div>
 <div class="footerl">
  <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
 </div>
   </body>
 </html>
