<?php require('session.php'); ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Labrotorist List</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/rabon.css">
    <link rel="stylesheet" href="css/stylephp.css">
    <script src="js/clock.js" charset="utf-8"></script>
    <script src="js/calander.js" charset="utf-8"></script>
    <script>
        function add(){
        var a,b,c;
        a=Number(document.getElementById("first").value);
        b=Number(document.getElementById("second").value);
        c= a + b;
        document.getElementById("answer").value= c;
        }
</script>
  </head>
  <body onload="displayCalendar(),startTime()">
    <!--1st header-->
    <div class="name">
      <h2>Hospital Management System</h2>
    </div>
    <!--Hospital Name End-->
    <!--1st header-->
    <div class="header">
        <div class="admin">
          <marquee behavior="alternate" scrollamount="2s"><h4><?php
          include('dbconnect.php');
            if (!mysqli_connect_errno()) {
              $query = "SELECT * FROM user WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);

              if($result){
                echo "Current User:-".$row['username'];
              }
            }?></h4></marquee>
        </div>
        <div class="logout">
          <a href="home.php">Home</a>
          <a href="doctor.php">Doctor's</a>
          <a href="nurse.php">Nurse</a>
          <a href="patient.php">Patient's</a>
          <a href="pharmacist.php">Pharamacist</a>
          <a href="labrotorist.php">Laboratist</a>
          <a href="accounts.php">Account's</a>
          <a href="profile.php">Profile</a>
          <a href="logout.php">Logout</a>
        </div>
    </div>
    <!--1st header end-->

    <!--Home page menue start-->
    <div class="menue">
      <a href="appoitmentlist.php">Appoinment</a>
      <a class= "active" href="blood.php">Bloodbank</a>
      <a href="medicine.php">Medicine</a>
      <a href="operationlist.php">Operation's</a>
      <a href="birthreport.php">Birth Report</a>
      <a href="deathreport.php">Death Report</a>
      <a href="#">Bed Allotment </a>
    </div>
    <!--Home page menue End-->
    <!--Analog Clock-->
    <div id="sabuj">
    <h1>Current Time</h1>
    <div id="a1"></div>
    </div>
      <!--Calander-->
        <div id="calendar"></div>
<!--Patient list-->
<div class="submenu">
  <a href="adblood.php">Add New Blood</a>
</div>
   <div class="non-semantic-protector">
        	<h1 class="ribbon">
        		<strong class="ribbon-content">Stock Blood List</strong>
        	</h1>
    </div>
    <table id="tbl">
      <tr>
        <th>Sl No</th>
        <th>Blood Group</th>
        <th>Add</th>
        <th>Use</th>
        <th>Total Add Blood (Packate)</th>
        <th>Total Use Blood(Packate)</th>
      </tr>
      <tr>
        <td>01</td>
        <td>A(+ve)</td>
        <td><form action="#" method="POST">
      		<input type="number" name="bloods">
      		<input type="submit" name="submit" value="Add Blood">
      	</form>
        <?php
        include('dbblood.php');
        if(isset($_POST['submit'])){
        $bloods = $_POST['bloods'];
          if(!mysqli_connect_errno()){
            $query = "INSERT INTO aaad (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
            if(mysqli_query($connection,$query)){
            }
          }

}

             if (!mysqli_connect_errno()) {
               $query = "SELECT * FROM aaad WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);
               if($result){

          $sl_no = 0;
          $tb = 0;
          while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
            $sl_no = $sl_no + 1;
            $tb += $row['number'];
            $id = $row['id'];

        }
          }
        }else{
          die("ERROR : ".mysqli_connect_error());
        }
        mysqli_close($connection);
        ?>
      </td>
      <td><form action="#" method="POST">
        <input type="number" name="ublood">
        <input type="submit" name="aause" value="Use Blood">
      </form>
      <?php
      include('dbblood.php');
      if(isset($_POST['aause'])){
      $bloods = $_POST['ublood'];
        if(!mysqli_connect_errno()){
          $query = "INSERT INTO aaus (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
          if(mysqli_query($connection,$query)){
          }
        }

}

           if (!mysqli_connect_errno()) {
             $query = "SELECT * FROM aaus WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);
             if($result){

        $sl_no = 0;
        $a1 = 0;
        while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
          $sl_no = $sl_no + 1;
          $a1 += $row['number'];
          $id = $row['id'];

      }
        }
      }else{
        die("ERROR : ".mysqli_connect_error());
      }
      mysqli_close($connection);
      ?></td>
        <td><?php echo $tb;?></td>
        <td><?php echo $a1;?></td>
      </tr>
      <tr>
        <td>02</td>
        <td>A(-ve)</td>
        <td><form action="#" method="POST">
      		<input type="number" name="bloods">
      		<input type="submit" name="aamad" value="Add Blood">
      	</form>
        <?php
        include('dbblood.php');
        if(isset($_POST['aamad'])){
        $bloods = $_POST['bloods'];
          if(!mysqli_connect_errno()){
            $query = "INSERT INTO aamad (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
            if(mysqli_query($connection,$query)){
            }
          }

}

             if (!mysqli_connect_errno()) {
               $query = "SELECT * FROM aamad WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);
               if($result){

          $sl_no = 0;
          $tb = 0;
          while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
            $sl_no = $sl_no + 1;
            $tb += $row['number'];
            $id = $row['id'];

        }
          }
        }else{
          die("ERROR : ".mysqli_connect_error());
        }
        mysqli_close($connection);
        ?>
      </td>
      <td><form action="#" method="POST">
        <input type="number" name="ublood">
        <input type="submit" name="aamus" value="Use Blood">
      </form>
      <?php
      include('dbblood.php');
      if(isset($_POST['aamus'])){
      $bloods = $_POST['ublood'];
        if(!mysqli_connect_errno()){
          $query = "INSERT INTO aamus (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
          if(mysqli_query($connection,$query)){
          }
        }

}

           if (!mysqli_connect_errno()) {
             $query = "SELECT * FROM aamus WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);
             if($result){

        $sl_no = 0;
        $a1 = 0;
        while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
          $sl_no = $sl_no + 1;
          $a1 += $row['number'];
          $id = $row['id'];

      }
        }
      }else{
        die("ERROR : ".mysqli_connect_error());
      }
      mysqli_close($connection);
      ?></td>
        <td><?php echo $tb;?></td>
        <td><?php echo $a1;?></td>
      </tr>
      <tr>
        <td>03</td>
        <td>B(+ve)</td>
        <td><form action="#" method="POST">
      		<input type="number" name="bloods">
      		<input type="submit" name="bbad" value="Add Blood">
      	</form>
        <?php
        include('dbblood.php');
        if(isset($_POST['bbad'])){
        $bloods = $_POST['bloods'];
          if(!mysqli_connect_errno()){
            $query = "INSERT INTO bbad (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
            if(mysqli_query($connection,$query)){
            }
          }

}

             if (!mysqli_connect_errno()) {
               $query = "SELECT * FROM bbad WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);
               if($result){

          $sl_no = 0;
          $tb = 0;
          while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
            $sl_no = $sl_no + 1;
            $tb += $row['number'];
            $id = $row['id'];

        }
          }
        }else{
          die("ERROR : ".mysqli_connect_error());
        }
        mysqli_close($connection);
        ?>
      </td>
      <td><form action="#" method="POST">
        <input type="number" name="ublood">
        <input type="submit" name="bbus" value="Use Blood">
      </form>
      <?php
      include('dbblood.php');
      if(isset($_POST['bbus'])){
      $bloods = $_POST['ublood'];
        if(!mysqli_connect_errno()){
          $query = "INSERT INTO bbus (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
          if(mysqli_query($connection,$query)){
          }
        }

}

           if (!mysqli_connect_errno()) {
             $query = "SELECT * FROM bbus WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);
             if($result){

        $sl_no = 0;
        $a1 = 0;
        while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
          $sl_no = $sl_no + 1;
          $a1 += $row['number'];
          $id = $row['id'];

      }
        }
      }else{
        die("ERROR : ".mysqli_connect_error());
      }
      mysqli_close($connection);
      ?></td>
        <td><?php echo $tb;?></td>
        <td><?php echo $a1;?></td>
      </tr>
      <tr>
        <td>04</td>
        <td>B(-ve)</td>
        <td><form action="#" method="POST">
      		<input type="number" name="bloods">
      		<input type="submit" name="bbmad" value="Add Blood">
      	</form>
        <?php
        include('dbblood.php');
        if(isset($_POST['bbmad'])){
        $bloods = $_POST['bloods'];
          if(!mysqli_connect_errno()){
            $query = "INSERT INTO bbmad (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
            if(mysqli_query($connection,$query)){
            }
          }

}

             if (!mysqli_connect_errno()) {
               $query = "SELECT * FROM bbmad WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);
               if($result){

          $sl_no = 0;
          $tb = 0;
          while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
            $sl_no = $sl_no + 1;
            $tb += $row['number'];
            $id = $row['id'];

        }
          }
        }else{
          die("ERROR : ".mysqli_connect_error());
        }
        mysqli_close($connection);
        ?>
      </td>
      <td><form action="#" method="POST">
        <input type="number" name="ublood">
        <input type="submit" name="bbmus" value="Use Blood">
      </form>
      <?php
      include('dbblood.php');
      if(isset($_POST['bbmus'])){
      $bloods = $_POST['ublood'];
        if(!mysqli_connect_errno()){
          $query = "INSERT INTO bbmus (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
          if(mysqli_query($connection,$query)){
          }
        }

}

           if (!mysqli_connect_errno()) {
             $query = "SELECT * FROM bbmus WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);
             if($result){

        $sl_no = 0;
        $a1 = 0;
        while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
          $sl_no = $sl_no + 1;
          $a1 += $row['number'];
          $id = $row['id'];

      }
        }
      }else{
        die("ERROR : ".mysqli_connect_error());
      }
      mysqli_close($connection);
      ?></td>
        <td><?php echo $tb;?></td>
        <td><?php echo $a1;?></td>
      </tr>
      <tr>
        <td>05</td>
        <td>AB(+ve)</td>
        <td><form action="#" method="POST">
      		<input type="number" name="bloods">
      		<input type="submit" name="abad" value="Add Blood">
      	</form>
        <?php
        include('dbblood.php');
        if(isset($_POST['abad'])){
        $bloods = $_POST['bloods'];
          if(!mysqli_connect_errno()){
            $query = "INSERT INTO abad (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
            if(mysqli_query($connection,$query)){
            }
          }

}

             if (!mysqli_connect_errno()) {
               $query = "SELECT * FROM abad WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);
               if($result){

          $sl_no = 0;
          $tb = 0;
          while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
            $sl_no = $sl_no + 1;
            $tb += $row['number'];
            $id = $row['id'];

        }
          }
        }else{
          die("ERROR : ".mysqli_connect_error());
        }
        mysqli_close($connection);
        ?>
      </td>
      <td><form action="#" method="POST">
        <input type="number" name="ublood">
        <input type="submit" name="abus" value="Use Blood">
      </form>
      <?php
      include('dbblood.php');
      if(isset($_POST['abus'])){
      $bloods = $_POST['ublood'];
        if(!mysqli_connect_errno()){
          $query = "INSERT INTO abus (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
          if(mysqli_query($connection,$query)){
          }
        }

}

           if (!mysqli_connect_errno()) {
             $query = "SELECT * FROM abus WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);
             if($result){

        $sl_no = 0;
        $a1 = 0;
        while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
          $sl_no = $sl_no + 1;
          $a1 += $row['number'];
          $id = $row['id'];

      }
        }
      }else{
        die("ERROR : ".mysqli_connect_error());
      }
      mysqli_close($connection);
      ?></td>
        <td><?php echo $tb;?></td>
        <td><?php echo $a1;?></td>
      </tr>
      <tr>
        <td>06</td>
        <td>AB(-ve)</td>
        <td><form action="#" method="POST">
          <input type="number" name="bloods">
          <input type="submit" name="abmad" value="Add Blood">
        </form>
        <?php
        include('dbblood.php');
        if(isset($_POST['abmad'])){
        $bloods = $_POST['bloods'];
          if(!mysqli_connect_errno()){
            $query = "INSERT INTO abmad (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
            if(mysqli_query($connection,$query)){
            }
          }

}

             if (!mysqli_connect_errno()) {
               $query = "SELECT * FROM abmad WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);
               if($result){

          $sl_no = 0;
          $tb = 0;
          while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
            $sl_no = $sl_no + 1;
            $tb += $row['number'];
            $id = $row['id'];

        }
          }
        }else{
          die("ERROR : ".mysqli_connect_error());
        }
        mysqli_close($connection);
        ?>
      </td>
      <td><form action="#" method="POST">
        <input type="number" name="ublood">
        <input type="submit" name="abmus" value="Use Blood">
      </form>
      <?php
      include('dbblood.php');
      if(isset($_POST['abmus'])){
      $bloods = $_POST['ublood'];
        if(!mysqli_connect_errno()){
          $query = "INSERT INTO abmus (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
          if(mysqli_query($connection,$query)){
          }
        }

}

           if (!mysqli_connect_errno()) {
             $query = "SELECT * FROM abmus WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);
             if($result){

        $sl_no = 0;
        $a1 = 0;
        while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
          $sl_no = $sl_no + 1;
          $a1 += $row['number'];
          $id = $row['id'];

      }
        }
      }else{
        die("ERROR : ".mysqli_connect_error());
      }
      mysqli_close($connection);
      ?></td>
        <td><?php echo $tb;?></td>
        <td><?php echo $a1;?></td>
      </tr>
      <tr>
        <td>07</td>
        <td>O(+ve)</td>
        <td><form action="#" method="POST">
          <input type="number" name="bloods">
          <input type="submit" name="oad" value="Add Blood">
        </form>
        <?php
        include('dbblood.php');
        if(isset($_POST['oad'])){
        $bloods = $_POST['bloods'];
          if(!mysqli_connect_errno()){
            $query = "INSERT INTO oad (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
            if(mysqli_query($connection,$query)){
            }
          }

}

             if (!mysqli_connect_errno()) {
               $query = "SELECT * FROM oad WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);
               if($result){

          $sl_no = 0;
          $tb = 0;
          while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
            $sl_no = $sl_no + 1;
            $tb += $row['number'];
            $id = $row['id'];

        }
          }
        }else{
          die("ERROR : ".mysqli_connect_error());
        }
        mysqli_close($connection);
        ?>
      </td>
      <td><form action="#" method="POST">
        <input type="number" name="ublood">
        <input type="submit" name="ous" value="Use Blood">
      </form>
      <?php
      include('dbblood.php');
      if(isset($_POST['ous'])){
      $bloods = $_POST['ublood'];
        if(!mysqli_connect_errno()){
          $query = "INSERT INTO ous (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
          if(mysqli_query($connection,$query)){
          }
        }

}

           if (!mysqli_connect_errno()) {
             $query = "SELECT * FROM ous WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);
             if($result){

        $sl_no = 0;
        $a1 = 0;
        while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
          $sl_no = $sl_no + 1;
          $a1 += $row['number'];
          $id = $row['id'];

      }
        }
      }else{
        die("ERROR : ".mysqli_connect_error());
      }
      mysqli_close($connection);
      ?></td>
        <td><?php echo $tb;?></td>
        <td><?php echo $a1;?></td>
      </tr>
      <tr>
        <td>08</td>
        <td>O(-ve)</td>
        <td><form action="#" method="POST">
          <input type="number" name="bloods">
          <input type="submit" name="omad" value="Add Blood">
        </form>
        <?php
        include('dbblood.php');
        if(isset($_POST['omad'])){
        $bloods = $_POST['bloods'];
          if(!mysqli_connect_errno()){
            $query = "INSERT INTO omad (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
            if(mysqli_query($connection,$query)){
            }
          }

}

             if (!mysqli_connect_errno()) {
               $query = "SELECT * FROM omad WHERE `visible` = 1";
                $result = mysqli_query($connection, $query);
               if($result){

          $sl_no = 0;
          $tb = 0;
          while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
            $sl_no = $sl_no + 1;
            $tb += $row['number'];
            $id = $row['id'];

        }
          }
        }else{
          die("ERROR : ".mysqli_connect_error());
        }
        mysqli_close($connection);
        ?>
      </td>
      <td><form action="#" method="POST">
        <input type="number" name="ublood">
        <input type="submit" name="omus" value="Use Blood">
      </form>
      <?php
      include('dbblood.php');
      if(isset($_POST['omus'])){
      $bloods = $_POST['ublood'];
        if(!mysqli_connect_errno()){
          $query = "INSERT INTO omus (`number`,`visible`) VALUES ('{$bloods}','{$visibility}')";
          if(mysqli_query($connection,$query)){
          }
        }

}

           if (!mysqli_connect_errno()) {
             $query = "SELECT * FROM omus WHERE `visible` = 1";
              $result = mysqli_query($connection, $query);
             if($result){

        $sl_no = 0;
        $a1 = 0;
        while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
          $sl_no = $sl_no + 1;
          $a1 += $row['number'];
          $id = $row['id'];

      }
        }
      }else{
        die("ERROR : ".mysqli_connect_error());
      }
      mysqli_close($connection);
      ?></td>
        <td><?php echo $tb;?></td>
        <td><?php echo $a1;?></td>
      </tr>
    </table>
<!--
      <div class="footer">
        <p>Copyright &copy; <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script> Sabuj Chandra Roy- <a href="#">TUP-Off-BDJobs-29</a> LICT, Dinajpur.</p>
      </div>
    -->
  </body>
</html>
