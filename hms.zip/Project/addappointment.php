<?php
require('session.php');
 ?>
<?php
include('function.php');
include('dbconnect.php');
  if (isset($_POST['submit'])) {
    $dname = $_POST['dname'];
    $name = $_POST['name'];
    $fee = $_POST['fee'];
    $vdate = $_POST['vdate'];
    $vdate = mysql_date($vdate);
    $vtime = $_POST['vtime'];
    $gender = $_POST['sex'];
    $command = $_POST['commant'];
    $sql_read = "SELECT `id` FROM appoint";
    $sl_no = 0;
    $result = mysqli_query($connection,$sql_read);
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
    }
    $last_id = $sl_no;
    $last_id = $last_id + 1;
    $date = date('d-m-Y');
    $day=date("d",strtotime($date));
    $month=date("m",strtotime($date));
    $year=date("Y",strtotime($date));
    $whole_date=$year.$month.$day;
    $main="APP-".$whole_date.$last_id;
    // Insert the Unique ID into the Database in its specific column of the table
    $sql_write = "INSERT INTO `appoint` (`dname`, `name`, `fee`, `vdate`, `vtime`, `gender`, `commant`, `appid`, `visible`) VALUES('{$dname}', '{$name}', '{$fee}', '{$vdate}', '{$vtime}','{$gender}','{$command}', '{$main}', '{$visibility}')";
    if(!mysqli_query($connection, $sql_write)){
      echo "<script>alert('ERROR : Failed Please Try Again')</script>";
    }else{
      echo "<b><script>alert('SUCCESS : successfully');</script></b>";
      echo "<script>window.location.href = 'appoitmentlist.php'</script>";
    }
    mysqli_close($connection);
  }

 ?>
 <!DOCTYPE html>
 <html>
 <!--
 //Programar: Sabuj Chandra roy
 //Hospital Management System Project
 //Database name Project;
 //Uses All different table
 //Create Start date: 02-01-2018
 //Last Update: 07-03-2018
 -->
 <head>
   <meta charset="utf-8">
   <title>Appointment</title>
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="css/rabon.css">
   <link rel="stylesheet" href="css/stylephp.css">
   <link rel="stylesheet" href="css/jquery-ui.css">
   <script src="js/clock.js" charset="utf-8"></script>
   <script src="js/calander.js" charset="utf-8"></script>
   <script src="js/jquery-3.1.0.min.js"></script>
   <script src="js/jquery-ui.js"></script>
   <script>
     $( function() {
       $( "#dob" ).datepicker({
         changeMonth:true,
         changeYear: true
       });
     });
   </script>
</head>
 <body onload="displayCalendar(),startTime()" >
   <!--Hospital Name start-->
   <div class="name">
   <div style="float:left;color:white;font-weight:bold;"><p></p>Emergency Blood : +8801737909261</div>
   <div style="float:right;color:white;font-weight:bold;"><p></p>Emergency Embulance : +8801719470043</div>
     <h2>Hospital Management System</h2>
   </div>
   <!--Hospital Name End-->
   <!--1st header-->
   <div class="header">
       <div class="admin">
         <marquee behavior="alternate" scrollamount="2s"><h4><?php
         include('dbconnect.php');
           if (!mysqli_connect_errno()) {
             $query = "SELECT * FROM user WHERE `visible` = 1";
             $result = mysqli_query($connection, $query);

             if($result){
               echo "Current User:-".$row['username'];
             }
           }?></h4></marquee>
       </div>
       <div class="logout">
         <a href="home.php">Home</a>
         <a href="doctor.php">Doctor's</a>
         <a href="nurse.php">Nurse</a>
         <a href="patient.php">Patient's</a>
         <a href="pharmacist.php">Pharamacist</a>
         <a href="labrotorist.php">Laboratist</a>
         <a href="accounts.php">Account's</a>
         <a href="profile.php">Profile</a>
         <a href="logout.php">Logout</a>
       </div>
   </div>
   <!--1st header end-->

   <!--Home page menue start-->
   <div class="menue">
     <a class= "active" href="appoitmentlist.php">Appoinment</a>
     <a href="blood.php">Bloodbank</a>
     <a href="medicine.php">Medicine</a>
     <a href="operationlist.php">Operation's</a>
     <a href="birthreport.php">Birth Report</a>
     <a href="deathreport.php">Death Report</a>
     <a href="beddetails.php">Bed Status </a>
   </div>
   <!--Home page menue End-->
   <!--Analog Clock-->
   <div id="sabuj">
   <h1>Current Time</h1>
   <div id="a1"></div>
   </div>
     <!--Calander-->
<div class="calander">
 <div id="calendar"></div>
</div>
<div class="submenu">
  <a href="doctor.php">Back Doctor List</a>
</div>
       <!--Appointment Form-->
 <div class="non-semantic-protector">
          <h1 class="ribbon">
            <strong class="ribbon-content">Add New Appointment</strong>
          </h1>
  </div>
  <!--own immage-->
  <div class="dev" style="float:left; margin-left:5%">
  <h4 style="text-align:center;">Developer</h4>
       <img src="imge/sabuj.png" alt="" width:"200px" height="150px" style="border:1px solid lightgray; border-radius:50%;">
       <p><strong>Sabuj Chandra roy</strong><br>Beginer Web Developer</p>
     </div>
     <div class="dev" style="float:right; margin-right:5%">
       <h4 style="text-align:center;">My Honorable Trainer</h4>
       <img src="imge/suman.jpg" alt="" width:"200px" height="150px" style="border:1px solid lightgray; border-radius:50%;margin-left:20%;">
       <p><strong>Suman Gangopadhyay</strong><br>Trainer-Web Development,<strong>IIHT</strong></p>
     </div>
     <!--End imgage style-->
  <div class="main">
    <form class="form_div" action="#" method="post">
    <?php
    include('dbconnect.php');
    //=============================
    //This creates the drop down box
    echo "<span>"."Doctor Name:"."</span>";
    echo "<select class= 'sex' name= 'dname'>";
    echo '<option >'.'--- Select Doctor Name ---'.'</option>';
    //$query=mysqli_query($con,"SELECT id,FirstName FROM persons");
    $query = mysqli_query($connection,"SELECT dname FROM newdoctor WHERE `visible`=1");
    $query_display = mysqli_query($connection,"SELECT * FROM newdoctor WHERE `visible`=1");
    while($row=mysqli_fetch_array($query))
    {
        echo "<option ". $row['id']."'>".$row['dname']
     .'</option>';
    }
    echo '</select>';
    ?>

    <?php
    include('dbconnect.php');
    //=============================
    //This creates the drop down box
    echo "<span>"."Patient Name:"."</span>";
    echo "<select class= 'sex' name= 'name'>";
    echo '<option >'.'--- Select Patient Name ---'.'</option>';
    //$query=mysqli_query($con,"SELECT id,FirstName FROM persons");
    $query = mysqli_query($connection,"SELECT name FROM adpatient WHERE `visible`=1");
    $query_display = mysqli_query($connection,"SELECT * FROM adpatient WHERE `visible`=1");
    while($row=mysqli_fetch_array($query))
    {
        echo "<option ". $row['id']."'>".$row['name']
     .'</option>';
    }
    echo '</select>';
    ?>
    <span>Visiting Fee: </span>
      <input type="text" name="fee" placeholder="Visiting Fee" required>
      <span>Visiting Date:</span>
      <input type="text" id="dob" name="vdate" placeholder="Visiting Date" required>
      <span>Visiting Time:</span>
      <input type="time" name="vtime" placeholder="Visiting Time" required>
      <span>Gender:</span>
      <select class="sex" name="sex">
          <option>Gender</option>
          <option>M</option>
          <option>F</option>
      </select>
      <span>Problem Task: </span>
      <textarea name="commant" placeholder="Porblem task"></textarea>

      <input type="reset" name="reset" value="Clear">
      <input type="submit" name="submit" value="Get ID">
    </form>
  </div>
  <!--

   </body>
 </html>
