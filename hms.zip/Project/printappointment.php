<?php require('session.php'); ?>
<?php
//PROGRAM : PHP program to UPDATE a Record in MySQL database for the CRUD App
//CODED BY : Sabuj Chandra Roy
//DATABASE NAME : php_mysqli
//Table Name : userinfo
//DATE : 20-July-2014
include('dbconnect.php');
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT * FROM appoint WHERE `id`='{$id}'";
  $result = mysqli_query($connection,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $dname=$row['dname'];
    $name=$row['name'];
    $fee=$row['fee'];
    $vdate=$row['vdate'];
    $vtime = $row['vtime'];
    $command = $row['commant'];
    $appid = $row['appid'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection);
 ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Print Appointment</title>
    <link rel="stylesheet" href="css/printappoin.css">
    <script type="text/javascript">
    function printDiv(main) {
  var printContents = document.getElementById(main).innerHTML;
  var originalContents = document.body.innerHTML;

  document.body.innerHTML = printContents;

  window.print();

  document.body.innerHTML = originalContents;
}
    </script>
  </head>
  <body>

<div class="back" style="margin-left:15%;margin-top:15px; border:1px solid dodgerblue; width:40px; text-align:center; background-color:lightgray;"><a href="appoitmentlist.php" style="text-decoration:none;font-weight:bold;">Back</a></div>
    <div id="printableArea" class="main">
      <input type="button" onclick="printDiv('printableArea')" value="print" />
      <!--Header Are-->
      <div class="header">

        <div class="dname">
          <h2>Doctor Name: Dr.<?php echo $dname;?></h2>
          <p>MBBS, DBMS (Dhaka)<br>Professior, Dhaka Medical College, Dhaka</P>

        </div>
        <div class="hosname">
          <h2>Dhaka Medical College</h2>
            <p> Uttra, Dhaka-1200<br>Phone: 123456987</p>
        </div>
        <div class="appoin">
<h3>Appoint ID:&nbsp;&nbsp;&nbsp;<i><?php echo $appid;?></i> </h3>
</div>
    </div>
      <!--End of Header Area-->


    <div class="details">
      <p>Patient Name :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b> <?php echo $name;?></b><br> Consultancy Fees:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<?php echo $fee;?> <br> Appointment Date:&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $vdate;?><br> Appointment Time:&nbsp; &nbsp;&nbsp;&nbsp;<?php echo $vtime;?> <br> Details:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $command;?> <br></p>

    </div>
  </div>
  </body>
</html>
